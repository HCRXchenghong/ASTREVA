--
-- PostgreSQL database dump
--

\restrict mVsyTxDwExUfwrA3wJmmgm27SNzi74dqbIpAVWMYBm7zh6Xc9ioHUbuVkAMNKsb

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_users (
    id text NOT NULL,
    account text NOT NULL,
    name text NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id text NOT NULL,
    account text NOT NULL,
    name text NOT NULL,
    group_name text DEFAULT ''::text NOT NULL,
    password_hash text NOT NULL,
    status text DEFAULT 'offline'::text NOT NULL,
    max_conversations integer DEFAULT 10 NOT NULL,
    current_conversations integer DEFAULT 0 NOT NULL,
    disabled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    device_token text DEFAULT ''::text NOT NULL,
    avatar_url text DEFAULT ''::text NOT NULL,
    manual_satisfaction_rate double precision,
    CONSTRAINT agents_current_conversations_check CHECK ((current_conversations >= 0)),
    CONSTRAINT agents_max_conversations_check CHECK ((max_conversations >= 0)),
    CONSTRAINT agents_status_check CHECK ((status = ANY (ARRAY['online'::text, 'busy'::text, 'offline'::text])))
);


--
-- Name: ai_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_settings (
    id smallint DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    mode text DEFAULT 'human_first'::text NOT NULL,
    base_url text DEFAULT 'https://api.openai.com/v1'::text NOT NULL,
    api_key_ciphertext text DEFAULT ''::text NOT NULL,
    model text DEFAULT 'gpt-4o-mini'::text NOT NULL,
    api_type text DEFAULT 'chat_completions'::text NOT NULL,
    temperature numeric(3,2) DEFAULT 0.70 NOT NULL,
    max_output_tokens integer DEFAULT 512 NOT NULL,
    timeout_seconds integer DEFAULT 20 NOT NULL,
    system_prompt text DEFAULT ''::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ai_settings_api_type_check CHECK ((api_type = ANY (ARRAY['chat_completions'::text, 'responses'::text, 'anthropic_messages'::text]))),
    CONSTRAINT ai_settings_mode_check CHECK ((mode = ANY (ARRAY['human_first'::text, 'always_ai'::text, 'manual_only'::text]))),
    CONSTRAINT ai_settings_singleton CHECK ((id = 1)),
    CONSTRAINT ai_settings_temperature_check CHECK (((temperature >= (0)::numeric) AND (temperature <= (2)::numeric)))
);


--
-- Name: app_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_releases (
    id text NOT NULL,
    platform text NOT NULL,
    version_name text NOT NULL,
    version_code bigint NOT NULL,
    file_name text DEFAULT ''::text NOT NULL,
    file_path text NOT NULL,
    download_url text DEFAULT ''::text NOT NULL,
    file_size bigint DEFAULT 0 NOT NULL,
    checksum text DEFAULT ''::text NOT NULL,
    release_notes text DEFAULT ''::text NOT NULL,
    force_update boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT app_releases_platform_check CHECK ((platform = ANY (ARRAY['android'::text, 'ios'::text])))
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id text NOT NULL,
    actor_kind text NOT NULL,
    actor_id text DEFAULT ''::text NOT NULL,
    action text NOT NULL,
    resource text DEFAULT ''::text NOT NULL,
    resource_id text DEFAULT ''::text NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    user_agent text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT audit_events_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['admin'::text, 'agent'::text, 'visitor'::text])))
);


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sessions (
    token text NOT NULL,
    kind text NOT NULL,
    account_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT auth_sessions_kind_check CHECK ((kind = ANY (ARRAY['admin'::text, 'agent'::text, 'visitor'::text])))
);


--
-- Name: business_hours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_hours (
    id smallint DEFAULT 1 NOT NULL,
    timezone text DEFAULT 'Asia/Shanghai'::text NOT NULL,
    start_time text DEFAULT '09:00'::text NOT NULL,
    end_time text DEFAULT '18:00'::text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT business_hours_singleton CHECK ((id = 1))
);


--
-- Name: contact_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_settings (
    id smallint DEFAULT 1 NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    wechat text DEFAULT ''::text NOT NULL,
    wechat_reply_type text DEFAULT 'image'::text NOT NULL,
    wechat_image_url text DEFAULT ''::text NOT NULL,
    qq text DEFAULT ''::text NOT NULL,
    qq_reply_type text DEFAULT 'text'::text NOT NULL,
    qq_image_url text DEFAULT ''::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    entry_reply text DEFAULT ''::text NOT NULL,
    CONSTRAINT contact_settings_qq_reply_type_check CHECK ((qq_reply_type = ANY (ARRAY['text'::text, 'image'::text]))),
    CONSTRAINT contact_settings_singleton CHECK ((id = 1)),
    CONSTRAINT contact_settings_wechat_reply_type_check CHECK ((wechat_reply_type = ANY (ARRAY['text'::text, 'image'::text])))
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id text NOT NULL,
    visitor_id text NOT NULL,
    visitor_ip inet NOT NULL,
    visitor_remark text NOT NULL,
    remark_updated_by text DEFAULT ''::text NOT NULL,
    remark_updated_at timestamp with time zone,
    status text NOT NULL,
    assigned_agent_id text,
    source text DEFAULT 'web'::text NOT NULL,
    last_message text DEFAULT ''::text NOT NULL,
    last_message_at timestamp with time zone,
    unread_for_agent integer DEFAULT 0 NOT NULL,
    unread_for_visitor integer DEFAULT 0 NOT NULL,
    closed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT conversations_status_check CHECK ((status = ANY (ARRAY['waiting'::text, 'assigned'::text, 'ai_serving'::text, 'human_requested'::text, 'closed'::text]))),
    CONSTRAINT conversations_unread_agent_check CHECK ((unread_for_agent >= 0)),
    CONSTRAINT conversations_unread_visitor_check CHECK ((unread_for_visitor >= 0))
);


--
-- Name: keyword_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.keyword_rules (
    id text NOT NULL,
    keyword text NOT NULL,
    match_type text DEFAULT 'contains'::text NOT NULL,
    reply text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    action text DEFAULT 'text'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    show_in_quick_replies boolean DEFAULT false NOT NULL,
    quick_reply_text text DEFAULT ''::text NOT NULL,
    CONSTRAINT keyword_rules_action_check CHECK ((action = ANY (ARRAY['text'::text, 'telephone'::text, 'whatsapp'::text, 'telegram'::text, 'handoff'::text]))),
    CONSTRAINT keyword_rules_match_type_check CHECK ((match_type = ANY (ARRAY['contains'::text, 'exact'::text, 'prefix'::text])))
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    server_msg_id text NOT NULL,
    client_msg_id text DEFAULT ''::text NOT NULL,
    conversation_id text NOT NULL,
    sender_type text NOT NULL,
    sender_id text DEFAULT ''::text NOT NULL,
    message_type text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by_kind text DEFAULT ''::text NOT NULL,
    revoked_by_id text DEFAULT ''::text NOT NULL,
    CONSTRAINT messages_message_type_check CHECK ((message_type = ANY (ARRAY['text'::text, 'emoji'::text, 'image'::text, 'audio'::text, 'contact_phone'::text, 'contact_wechat'::text, 'contact_telephone'::text, 'contact_whatsapp'::text, 'contact_telegram'::text, 'system'::text, 'ai_text'::text, 'handoff_request'::text, 'revoked'::text]))),
    CONSTRAINT messages_sender_type_check CHECK ((sender_type = ANY (ARRAY['visitor'::text, 'agent'::text, 'ai'::text, 'system'::text])))
);


--
-- Name: service_ratings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_ratings (
    id text NOT NULL,
    conversation_id text NOT NULL,
    visitor_id text NOT NULL,
    assigned_agent_id text,
    score integer NOT NULL,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    comment text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT service_ratings_score_check CHECK (((score >= 1) AND (score <= 5)))
);


--
-- Name: site_admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_admin_users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    totp_secret text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_audit_events (
    id text NOT NULL,
    actor_id text DEFAULT ''::text NOT NULL,
    actor_email text DEFAULT ''::text NOT NULL,
    action text NOT NULL,
    resource text DEFAULT ''::text NOT NULL,
    resource_id text DEFAULT ''::text NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    user_agent text DEFAULT ''::text NOT NULL,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_content (
    id smallint DEFAULT 1 NOT NULL,
    content jsonb NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT site_content_id_check CHECK ((id = 1))
);


--
-- Name: site_content_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_content_translations (
    locale text NOT NULL,
    content jsonb,
    source_revision bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT site_content_translations_locale_check CHECK ((locale = ANY (ARRAY['en'::text, 'ar'::text]))),
    CONSTRAINT site_content_translations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'ready'::text, 'failed'::text, 'unconfigured'::text])))
);


--
-- Name: site_fallback_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_fallback_state (
    id smallint DEFAULT 1 NOT NULL,
    active_version_id text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT site_fallback_state_id_check CHECK ((id = 1))
);


--
-- Name: site_fallback_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_fallback_versions (
    id text NOT NULL,
    name text NOT NULL,
    content jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: site_leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_leads (
    id text NOT NULL,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    data jsonb NOT NULL
);


--
-- Name: site_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_media (
    id text NOT NULL,
    name text NOT NULL,
    object_key text NOT NULL,
    url text NOT NULL,
    mime_type text DEFAULT ''::text NOT NULL,
    media_type text DEFAULT 'file'::text NOT NULL,
    size_bytes bigint DEFAULT 0 NOT NULL,
    storage_driver text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    category text DEFAULT '未分类'::text NOT NULL,
    source_type text DEFAULT 'upload'::text NOT NULL,
    original_key text DEFAULT ''::text NOT NULL,
    width integer,
    height integer,
    checksum_sha256 text DEFAULT ''::text NOT NULL,
    variants jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT site_media_media_type_check CHECK ((media_type = ANY (ARRAY['image'::text, 'video'::text, 'file'::text])))
);


--
-- Name: site_media_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_media_categories (
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: site_publish_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_publish_jobs (
    id text NOT NULL,
    status text NOT NULL,
    requested_by text DEFAULT ''::text NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    error_message text DEFAULT ''::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT site_publish_jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: site_runtime_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_runtime_settings (
    setting_key text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    encrypted_secrets text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: visitors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visitors (
    id text NOT NULL,
    ip inet NOT NULL,
    remark text NOT NULL,
    source text DEFAULT 'web'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_users (id, account, name, password_hash, created_at) FROM stdin;
admin_super	superadmin	超级管理员	bcrypt:$2a$10$gnQVdIq.vTU8DUyQ8PupX.InMk9LuciSqhZMF683fh3nlA/QvAH8C	2026-08-28 03:51:26.597466+00
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agents (id, account, name, group_name, password_hash, status, max_conversations, current_conversations, disabled_at, created_at, updated_at, device_token, avatar_url, manual_satisfaction_rate) FROM stdin;
agent_lixue	admin	客服-李雪	售前组	bcrypt:$2a$10$v8y7Ry6jGL6Jcow/5J0CXusiUab3DRJaJMAJWMHTWBNv7d1ONj99m	offline	10	0	\N	2026-08-28 03:51:26.599023+00	2026-08-28 03:51:26.599023+00			\N
\.


--
-- Data for Name: ai_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_settings (id, enabled, mode, base_url, api_key_ciphertext, model, api_type, temperature, max_output_tokens, timeout_seconds, system_prompt, updated_at) FROM stdin;
1	t	human_first	https://api.hcrx.ltd/v1	enc:v1:NUwDCF6r7goGaTlufDcGifc1wo+CU2IJGTIDZ70KesyMYAVmYvKRGuUbiY0NXHOiakB3WoCAYlpWiFtyC9Nl494/i7b41HIolkZgNktXEbqcP1iv2X8jQdBK4JJeMyI	gpt-5.6-terra	responses	0.70	1024	20	你是一个专业的在线客服助手，名为ASTREVA助手，你使用的大模型是自主开发的ASTREVA-2.0；你要根据客户说哪一国家的语言而回复对应的语言，你的母语是阿拉伯语和英语，别人问你之后你先说你是谁，然后再说“您好，请您回复以下细节\n1  材质201/304（特殊材质可备注）：\n2 尺寸（可直接发图纸):\n3 数量(米/个）：”然后客户发什么你就回什么，我们是做不锈钢的厂家，市面上大部分的不锈钢产品我们都可以做，但是主营的是不锈钢凹槽，如果客户问多少钱你就说可以输入人工客服召唤您的私人专员报价；然后如果你发现客户一直在询问价格，也就是对价格敏感的话，就告诉他“老板，如果咱的工厂水的流通量不是特别大的情况下，为了节省成本，咱可以用201材质的，板材的厚度也关系到价格，这个就要看您水槽上面需要承重多少，一般来说在加工工艺相同的情况下，材料越厚价格越高。再就是平底沟的价格相对便宜。”再就是如果他问多少钱了或者要召唤专员的时候，你可以告诉他“您把您需要的总米数和承重要求 发给我们专员，我们公司可以给你生成几个不同的报价方案供您选择”	2026-08-29 01:44:23.568509+00
\.


--
-- Data for Name: app_releases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_releases (id, platform, version_name, version_code, file_name, file_path, download_url, file_size, checksum, release_notes, force_update, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_events (id, actor_kind, actor_id, action, resource, resource_id, ip_address, user_agent, description, created_at) FROM stdin;
audit_9924d02e312c92a8	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 05:43:30.40998+00
audit_bdc4a97b76ac183d	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 05:43:30.410459+00
audit_f7b2cb394a966759	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 05:43:30.418979+00
audit_d655357c3c037f15	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 05:43:30.419531+00
audit_724f733c728700c7	admin	admin_super	conversation.close	conversation	conv_7217ee0988c5963bd3fc	172.19.0.8	node	关闭会话	2026-08-28 05:43:38.046836+00
audit_56c741f1cb4f78b6	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 09:15:43.359171+00
audit_dde9336e7187fdaf	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 09:15:43.365142+00
audit_0ef8f7c963cc4087	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 09:15:43.367571+00
audit_a9f1d81f4a90ed06	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-28 09:15:43.370471+00
audit_2d7d6ab5e7be048b	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-29 01:19:34.346029+00
audit_e647fd38a85f2f3c	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-29 01:19:34.352318+00
audit_7eb1b2432bf31d59	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-29 01:19:34.352316+00
audit_490d49c25f4ce7c8	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-29 01:19:34.357264+00
audit_3b9d4b910f15f517	admin	admin_super	admin.login.succeeded	auth_session		172.19.0.8	node	登录成功	2026-08-29 01:27:42.307509+00
audit_6106ecb7ce545fde	admin	admin_super	ai_settings.models_sync	ai_settings	1	172.19.0.8	node	从上游接口获取 AI 模型列表	2026-08-29 01:30:52.583949+00
audit_a27ee52acfec29d5	admin	admin_super	ai_settings.update	ai_settings	1	172.19.0.8	node	更新 AI 配置	2026-08-29 01:38:29.158025+00
audit_7fdebad213f1ed16	admin	admin_super	ai_settings.update	ai_settings	1	172.19.0.8	node	更新 AI 配置	2026-08-29 01:44:23.570818+00
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_sessions (token, kind, account_id, created_at, expires_at, revoked_at) FROM stdin;
v_8256d7c4ee05a04aa69b0fba84b3c73c9ca77073c2d4fe27	visitor	conv_7217ee0988c5963bd3fc	2026-08-28 05:35:10.817168+00	2026-09-27 05:35:10.817168+00	\N
a_e38827847c87c2e6a520202ff2d8f74f3b94b615a5f862ac	admin	admin_super	2026-08-28 05:43:30.407311+00	2026-08-29 05:43:30.407311+00	\N
a_a876f8d075a160afa2aeb73b5c9be1fe70958fe22d72d4d3	admin	admin_super	2026-08-28 05:43:30.407896+00	2026-08-29 05:43:30.407896+00	\N
a_05393cb347b2d895db5d61ff68b11a1c4c8af078e155e7c9	admin	admin_super	2026-08-28 05:43:30.416576+00	2026-08-29 05:43:30.416576+00	\N
a_688b257b0b6d695fcfe074248b26d5db349f843820ef858d	admin	admin_super	2026-08-28 05:43:30.417977+00	2026-08-29 05:43:30.417977+00	\N
v_13ca3224433aee16a1644577d2aef71e930842607952c904	visitor	conv_966bf01bb0e0dac57202	2026-08-28 05:43:59.820996+00	2026-09-27 05:43:59.820996+00	\N
v_08a439bdaafee23350a6109b84390a18be135fe9a6f4e8dc	visitor	conv_a0b42b9a2e926c230319	2026-08-28 08:09:49.751126+00	2026-09-27 08:09:49.751126+00	\N
v_5ad74a1bfdc3655e747deb7dc47eb8a788641f36825ed9bc	visitor	conv_ae5da5fb96d7ebea7cd7	2026-08-28 08:09:50.1275+00	2026-09-27 08:09:50.1275+00	\N
a_abe71184dd4f2d8ed6bff544f88352f6a84e1e3b21bbddd5	admin	admin_super	2026-08-28 09:15:43.356829+00	2026-08-29 09:15:43.356829+00	\N
a_f3e44cf50a3447d2f05b0969d06e79c5036170001aa5952a	admin	admin_super	2026-08-28 09:15:43.364122+00	2026-08-29 09:15:43.364122+00	\N
a_f5a01d2004561b7e3bfd8c5beb77e061ba7797278bdfcaaf	admin	admin_super	2026-08-28 09:15:43.366917+00	2026-08-29 09:15:43.366917+00	\N
a_a19f527d186008a6f1b78d4567d51e0afd948d21a3e05936	admin	admin_super	2026-08-28 09:15:43.369516+00	2026-08-29 09:15:43.369516+00	\N
v_d6cbd9443b3594fc3d260f554e9f3a3bea686491d2510913	visitor	conv_6887705827d5c30faea4	2026-08-29 01:12:38.452021+00	2026-09-28 01:12:38.452021+00	\N
a_ddfb069fbcca90968bfaafafb7aa5e25d5706725c3b97776	admin	admin_super	2026-08-29 01:19:34.343755+00	2026-08-30 01:19:34.343755+00	\N
a_99c32479a335b56cf6d1a88c35882203b6c8cec9ace5fe70	admin	admin_super	2026-08-29 01:19:34.347805+00	2026-08-30 01:19:34.347805+00	\N
a_541caf82f2a34c13665c47455f266538ffb83c7f778536c8	admin	admin_super	2026-08-29 01:19:34.348769+00	2026-08-30 01:19:34.348769+00	\N
a_84980ba10c3b12eddac5ee93ab4cdcf5fe8008e5b5ea2f32	admin	admin_super	2026-08-29 01:19:34.356284+00	2026-08-30 01:19:34.356284+00	\N
a_962f8e83f22c7c13515fcb163b4687b73ce0069021b56e8d	admin	admin_super	2026-08-29 01:27:42.3063+00	2026-08-30 01:27:42.3063+00	\N
v_01faeed3a9ad062c0800415d9d4c5662d14ab30b6e3f4523	visitor	conv_4a9b93fb97121d847377	2026-08-29 05:33:39.061694+00	2026-09-28 05:33:39.061694+00	\N
\.


--
-- Data for Name: business_hours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_hours (id, timezone, start_time, end_time, enabled, updated_at) FROM stdin;
1	Asia/Shanghai	09:00	18:00	t	2026-08-28 03:51:17.174303+00
\.


--
-- Data for Name: contact_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_settings (id, phone, wechat, wechat_reply_type, wechat_image_url, qq, qq_reply_type, qq_image_url, updated_at, entry_reply) FROM stdin;
1	400-123-4567	+86 400 888 8888	text		@AstrevaSupport	text		2026-08-28 03:51:17.172425+00	您好，欢迎咨询在线客服，请问有什么可以帮您？
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, visitor_id, visitor_ip, visitor_remark, remark_updated_by, remark_updated_at, status, assigned_agent_id, source, last_message, last_message_at, unread_for_agent, unread_for_visitor, closed_at, created_at, updated_at) FROM stdin;
conv_7217ee0988c5963bd3fc	vis_ebec0f91287df5a5	172.19.0.1	172.19.0.1		\N	closed	\N	web_mobile	新会话	2026-08-28 05:35:10.798868+00	0	0	2026-08-28 05:43:38.042563+00	2026-08-28 05:35:10.798868+00	2026-08-28 05:43:38.042563+00
conv_966bf01bb0e0dac57202	vis_9e4c0a6bd041a62a	172.19.0.1	172.19.0.1		\N	waiting	\N	web_mobile	你好？	2026-08-28 05:44:05.377721+00	1	0	\N	2026-08-28 05:43:59.81524+00	2026-08-28 05:44:05.377721+00
conv_ae5da5fb96d7ebea7cd7	vis_9ad00c05220db2c5	172.19.0.1	172.19.0.1		\N	waiting	\N	web_pc	新会话	2026-08-28 08:09:50.124576+00	0	0	\N	2026-08-28 08:09:50.124576+00	2026-08-28 08:09:50.124576+00
conv_a0b42b9a2e926c230319	vis_eadb4898c358885f	172.19.0.1	172.19.0.1		\N	closed	\N	web_mobile	新会话	2026-08-28 08:09:49.74105+00	0	0	2026-08-28 08:09:58.514774+00	2026-08-28 08:09:49.74105+00	2026-08-28 08:09:58.514774+00
conv_6887705827d5c30faea4	vis_e574921ed2adcf16	172.19.0.1	172.19.0.1		\N	closed	\N	web_mobile	hello？	2026-08-29 01:38:47.197898+00	1	0	2026-08-29 03:23:01.326642+00	2026-08-29 01:12:38.435902+00	2026-08-29 03:23:01.326642+00
conv_4a9b93fb97121d847377	vis_d982430e22cda2cb	172.19.0.1	172.19.0.1		\N	waiting	\N	web_mobile	你好？	2026-08-29 05:33:59.740953+00	1	0	\N	2026-08-29 05:33:39.046+00	2026-08-29 05:33:59.740953+00
\.


--
-- Data for Name: keyword_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.keyword_rules (id, keyword, match_type, reply, enabled, priority, action, created_at, updated_at, show_in_quick_replies, quick_reply_text) FROM stdin;
kw_phone	电话	contains	客服电话：400-123-4567	t	90	telephone	2026-08-28 03:51:17.171269+00	2026-08-28 03:51:17.171269+00	f	
kw_whatsapp	WhatsApp	contains	官方 WhatsApp：+86 400 888 8888	t	80	whatsapp	2026-08-28 03:51:17.171269+00	2026-08-28 03:51:17.171269+00	f	
kw_telegram	Telegram	contains	官方 Telegram：@AstrevaSupport	t	75	telegram	2026-08-28 03:51:17.171269+00	2026-08-28 03:51:17.171269+00	f	
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (server_msg_id, client_msg_id, conversation_id, sender_type, sender_id, message_type, content, created_at, revoked_at, revoked_by_kind, revoked_by_id) FROM stdin;
msg_fd320d4c4f62d7f484cda169		conv_7217ee0988c5963bd3fc	ai	ai	ai_text	您好，欢迎咨询在线客服，请问有什么可以帮您？	2026-08-28 05:35:10.814322+00	\N		
msg_104257dac0d890759602bc49		conv_7217ee0988c5963bd3fc	system	system	system	会话已结束	2026-08-28 05:43:38.043404+00	\N		
msg_00f6ca119a2f1506b28e29b3		conv_966bf01bb0e0dac57202	ai	ai	ai_text	您好，欢迎咨询在线客服，请问有什么可以帮您？	2026-08-28 05:43:59.819883+00	\N		
msg_70bde3e67d36ff21a3002435	web_mtcj0v8u_vsw5w15i9t	conv_966bf01bb0e0dac57202	visitor	vis_9e4c0a6bd041a62a	text	你好？	2026-08-28 05:44:05.377721+00	\N		
msg_5aa64d82f675b7d3ca50eb43		conv_a0b42b9a2e926c230319	ai	ai	ai_text	您好，欢迎咨询在线客服，请问有什么可以帮您？	2026-08-28 08:09:49.749011+00	\N		
msg_2859a7d55588e52327e7fce2		conv_ae5da5fb96d7ebea7cd7	ai	ai	ai_text	您好，欢迎咨询在线客服，请问有什么可以帮您？	2026-08-28 08:09:50.126992+00	\N		
msg_8656658cff4d3573d37e4ea0		conv_a0b42b9a2e926c230319	system	system	system	会话已结束	2026-08-28 08:09:58.515707+00	\N		
msg_759679dcaa305c842c0becd6		conv_6887705827d5c30faea4	ai	ai	ai_text	您好，欢迎咨询在线客服，请问有什么可以帮您？	2026-08-29 01:12:38.449871+00	\N		
msg_c5b2d8f3a2d1a486cd732f23	web_mtdpp99j_mwikxm706v	conv_6887705827d5c30faea4	visitor	vis_e574921ed2adcf16	text	hello？	2026-08-29 01:38:47.197898+00	\N		
msg_7d1e351f27c6cbea2b8d65e1		conv_6887705827d5c30faea4	system	system	system	会话已结束	2026-08-29 03:23:01.331544+00	\N		
msg_b5f86d4e60cc42e378e5cd10		conv_4a9b93fb97121d847377	ai	ai	ai_text	您好，欢迎咨询在线客服，请问有什么可以帮您？	2026-08-29 05:33:39.059784+00	\N		
msg_a3e13c35e2b61155c6574e5c	web_mtdy3qla_zk9oh555lap	conv_4a9b93fb97121d847377	visitor	vis_d982430e22cda2cb	text	你好？	2026-08-29 05:33:59.740953+00	\N		
\.


--
-- Data for Name: service_ratings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_ratings (id, conversation_id, visitor_id, assigned_agent_id, score, tags, comment, created_at) FROM stdin;
rate_8e642684b8e5cd32	conv_a0b42b9a2e926c230319	vis_eadb4898c358885f	\N	5	{非常满意}		2026-08-28 08:10:03.947549+00
rate_e9936ad642a97ffd	conv_6887705827d5c30faea4	vis_e574921ed2adcf16	\N	5	{"راضٍ جدًا"}		2026-08-29 03:23:03.607349+00
\.


--
-- Data for Name: site_admin_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_admin_users (id, email, password_hash, totp_secret, created_at, updated_at) FROM stdin;
2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	$2a$12$7UcDJIOAyW8ti8nngch/5.5mjqORWuKeR0WSlmyckRASgRvDKgug2	v1:sZIJX-lTT5Iu0tLm:F3PjJOqbHKfzvoGGHxCJsQ:Q_JYn6iYPF9AhKYMg-LiHSY4TlCsWYho3OVRyHs6oYY	2026-08-28 05:43:29.107+00	2026-08-28 05:43:29.116239+00
\.


--
-- Data for Name: site_audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_audit_events (id, actor_id, actor_email, action, resource, resource_id, ip_address, user_agent, detail, created_at) FROM stdin;
a6c05a01-4e32-4967-9815-5963b54b82ab			content.initialized	system				{"source": "immutable-container-seed"}	2026-08-28 03:53:02.689563+00
1dba47af-3273-4fc0-9443-0f8158147658		seroncheng@163.com	auth.setup.completed	admin-user	2a80c2a5-647a-4655-9cda-f30bc09425ea	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"email": "seroncheng@163.com"}	2026-08-28 05:43:29.122679+00
0fe5a852-ca1c-4616-a0ff-12b35a766636	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-terra", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-28 08:42:04.655165+00
5cf53279-f78a-4602-9db1-feddcc673561	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en,ar	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-28 08:42:10.684474+00
02e0eb1d-481d-487a-91bc-c2282535670c	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-terra", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-28 08:42:14.016624+00
c61f4e0a-49b6-40e9-ba4a-d5c5a42d6bf4	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-terra", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-28 08:47:12.625315+00
e8bc2a59-2644-4605-854a-0f7b3b077c0a	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-28 08:51:22.187797+00
2a02dbdf-d488-4bf2-8263-58eb4ec9951e	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-28 08:51:23.954957+00
5d3a3a31-16e2-4236-a8a4-bb5453bea01b	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-28 09:15:49.474485+00
ecc7a797-d6a5-4ab6-b2fd-6cda8c6b1ccd	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-28 09:15:55.06464+00
6da2ad7d-78fc-46e8-9e58-29e86bbdd02a		seroncheng@163.com	auth.login.completed	admin-user	2a80c2a5-647a-4655-9cda-f30bc09425ea	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"email": "seroncheng@163.com"}	2026-08-29 01:19:33.332145+00
97048cda-74f6-4d5a-8e32-915b9354a2a4	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:19:38.523065+00
92386e78-aba8-4f10-bfad-134e4e2b74e5	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en,ar	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 01:19:40.730049+00
b1610856-8b53-4aa5-8725-9f399f0ce932	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:19:46.727369+00
e2afc32b-fbb7-4c7c-945c-0f36d22ff713	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:20:11.673752+00
09b3c654-4549-4160-93cf-cc40b194d137	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:23:49.842261+00
1297e882-9558-4009-86b3-fb20e0af602e	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:24:10.066555+00
dd4d2c79-86a3-4680-8015-3372f95413f8	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:24:11.494448+00
4a99cb76-f4b4-4ae5-bbb2-9ae77e46780b	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:27:23.010202+00
dbf2ef73-e25e-4a62-8367-4c620a89d297	verify-test	verify@test.local	translation.settings.updated	website-translation		172.19.0.1	curl/7.81.0	{"model": "gpt-5.2", "apiType": "chat_completions", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:27:54.962656+00
b55a39cc-da3c-4603-96c5-80fee4fd38ca	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:29:57.330968+00
bbf190a9-4c96-4441-92c6-0187c7697535	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 01:44:46.485558+00
86066aab-726a-4888-95df-853e00d04810	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 02:41:47.380591+00
bf7e2a7b-f488-4c92-b7d4-6b8860fe2145	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 02:43:19.327427+00
0d50dfa3-b60b-4fb2-be07-15406fc5a7d7	verify-test	verify@test.local	translation.settings.updated	website-translation		172.19.0.1	node	{"model": "gpt-5.6-luna", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 02:49:44.368559+00
ca4d23a7-0e4a-4f2a-9914-3d5a61f55f76	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 03:09:51.529004+00
d396a00f-0ce1-4f40-9ff5-42d2407321a7	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 03:19:45.283211+00
29026c48-03c1-48da-8529-e7753b4eeb0f	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 03:26:08.144318+00
5d840d62-8744-48c3-86fb-d89d09e0ef42	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	ar	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 03:26:12.13399+00
27737b69-ea47-4142-abc7-87735b94de84	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.6-luna", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 03:26:19.081182+00
45b9fee4-8d3b-4122-83e9-d3f4350d8c9a	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 03:26:21.976184+00
60ed9347-3cf1-462a-914c-20bfb51f7194	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en,ar	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 03:26:44.390904+00
078a2f4c-a789-4cb7-aeef-3dc87e8e7f7f	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 03:32:44.196316+00
5c35ece7-82a5-46a9-bbeb-116ec0fb2598	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en,ar	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 03:32:45.909878+00
5c7be5af-dfdf-42fe-94da-49af2b5ecbd8	verify-test	verify@test.local	translation.requested	website-translation	en	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 03:37:33.276436+00
72e0959e-f6cb-4a6d-b470-a784b1ae37a2	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.settings.updated	website-translation		172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 03:40:29.554955+00
c7ea7ef4-f406-455f-a140-2c1c458a5e4a	2a80c2a5-647a-4655-9cda-f30bc09425ea	seroncheng@163.com	translation.requested	website-translation	en,ar	172.19.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"sourceRevision": 1}	2026-08-29 03:40:31.11429+00
40c838fe-847e-4334-af74-f2d1be667006	verify-test	verify@test.local	translation.requested	website-translation	en	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 03:49:08.985421+00
9605eb75-baa9-4bff-946f-15779b01e57c	verify-test	verify@test.local	translation.settings.updated	website-translation		172.19.0.1	curl/7.81.0	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 03:59:18.322587+00
b50506a4-5b7f-47e8-8ef0-0487a4789346	verify-test	verify@test.local	translation.settings.updated	website-translation		172.19.0.1	curl/7.81.0	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 04:02:32.951685+00
107b6751-0838-48aa-8f70-55e29d88523a	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:02:33.005983+00
efc712cf-1b22-4d06-9723-e0be46d2f72f	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:06:24.797832+00
02f13f8a-5440-4ae1-aea9-3593dd6910fa	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:16:43.478577+00
292a30d1-5d70-4c9b-b792-6f7ac4e017cc	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:21:39.640311+00
274ad84e-0176-4679-930d-dfbe9d0e17a1	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:28:26.858116+00
57879ef0-e6a5-4cbd-ad76-13750618f8de	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:32:27.667073+00
e51efca3-85b3-4450-841a-324040246fbf	verify-test	verify@test.local	translation.settings.updated	website-translation		172.19.0.1	curl/7.81.0	{"model": "gpt-5.6-luna", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 04:35:55.227069+00
2ef0de3f-4306-4a89-90ed-6b965c38dbbc	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:35:55.329376+00
c35d371c-65f0-458a-b3f2-95b8b5e0878f	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:41:15.553694+00
badc5580-393a-4482-906c-3dd33b9734d9	verify-test	verify@test.local	translation.settings.updated	website-translation		172.19.0.1	curl/7.81.0	{"model": "gpt-5.6-sol", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 04:48:47.240459+00
52f7ee23-e241-4a4e-9560-aa7963667b3a	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:48:47.295079+00
17302904-af62-4f38-9c77-7a2931600778	verify-test	verify@test.local	translation.settings.updated	website-translation		172.19.0.1	curl/7.81.0	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "apiKeyConfigured": true}	2026-08-29 04:54:48.222836+00
56662cd0-56a9-4526-bcc9-1f7d83195d4c	verify-test	verify@test.local	translation.requested	website-translation	en,ar	172.19.0.1	curl/7.81.0	{"sourceRevision": 1}	2026-08-29 04:54:48.289778+00
\.


--
-- Data for Name: site_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_content (id, content, revision, updated_at) FROM stdin;
1	{"faqs": [{"id": "faq_custom", "answer": "完全支持。除了标准化模块，我们的工程团队还可以根据您的现场地形、水力流量和曲线要求，定制异形、弧形及特殊宽度的不锈钢排水系统。", "enabled": true, "question": "你们的排水系统支持定制吗？", "sortOrder": 10}, {"id": "faq_click", "answer": "传统树脂混凝土或砖砌排水沟非常笨重，且需要繁琐的抹灰或现场焊接。我们的 Click 系统重量仅为传统的五分之一，且自带机械互锁防水卡扣，彻底免除了焊接与固化等待时间，即拼即用。", "enabled": true, "question": "Click系统为什么比传统的排水沟安装快这么多？", "sortOrder": 20}, {"id": "faq_load", "answer": "可以。我们特定的重载型号符合欧盟 EN1433 的 F900 级别，能承受机场跑道和重型物流仓储的极端负荷。", "enabled": true, "question": "产品能够承受重型卡车碾压吗？", "sortOrder": 30}, {"id": "faq_delivery", "answer": "对于常规型号和长度，我们拥有充足的库存，可在 3-5 个工作日内发货。如遇高度定制化的工程系统，生产周期通常在 2-4 周之间。", "enabled": true, "question": "订货周期一般是多久？", "sortOrder": 40}], "home": {"cta": {"title": "正在规划您的下一个项目？", "description": "如果您正好需要高效、美观且耐用的排水系统，请立即联系我们的工程专家团队获取免费报价。", "primaryHref": "/support/", "primaryLabel": "立即联系我们", "secondaryHref": "/products/", "secondaryLabel": "下载产品目录", "backgroundImage": ""}, "seo": {"title": "星渡ASTREVA | 模块化不锈钢排水系统", "description": "建筑与市政排水领域的创新方案，专注高效、美观、耐用的模块化不锈钢排水系统。"}, "hero": {"title": "星渡 ASTREVA", "eyebrow": "最快的排水系统。绝对的。", "subtitle": "建筑与市政排水领域的创新方案", "videoUrl": "https://youtube.com/shorts/XhHzoY3kG54?feature=share", "trademark": "TM", "primaryCta": "探索产品", "videoTitle": "星渡ASTREVA 宣传视频", "primaryHref": "/products/", "secondaryCta": "播放视频", "backgroundImage": "", "backgroundVideo": "", "videoCloseLabel": "关闭视频", "videoPreviewLabel": "宣传视频播放器 (预览)", "videoOpenExternalLabel": "无法播放？在 YouTube 打开"}, "partners": ["LANDLEASE", "LA SIMON BUILDERS", "MA CIVIL DESIGN", "MULTIPLEX", "BESIX Watpac"], "advantages": [{"icon": "▶", "title": "极速安装", "description": "专利 Click 咔哒锁扣系统，一秒拼接。"}, {"icon": "✓", "title": "极致耐用", "description": "提供高达 50 年的使用寿命质保。"}, {"icon": "工", "title": "超强承重", "description": "通过 Class G 承载力测试，适用于重载区。"}, {"icon": "滴", "title": "环保材料", "description": "100% 可回收不锈钢，助力 LEED 认证。"}], "partnerLabel": "我们的合作伙伴:", "productIntro": {"image": "", "title": "我们的产品是什么？", "bullets": ["100% 模块化设计，缩短80%工期", "轻量化材料，减少运输和人力成本", "无缝隙拼接，彻底杜绝渗漏", "美观的建筑级外观，适配任何地坪"], "ctaHref": "/products/", "ctaLabel": "查看技术规格", "bulletIcon": "✓", "description": "星渡ASTREVA 致力于研发和生产全球最快、最可靠的模块化排水系统。我们摒弃了传统笨重的排水沟渠，转而采用高强度不锈钢打造出点击即用的拼接系统。"}, "testimonials": [], "advantagesIntro": {"title": "体验产品优势", "description": "为什么全球顶尖的承包商和建筑师选择 星渡ASTREVA？"}, "featuredProducts": {"title": "产品展示", "linkIcon": "→", "linkLabel": "了解更多", "description": "探索我们全系列的高性能排水产品，专为各类建筑与市政需求设计。"}, "testimonialsTitle": "我们的客户怎么评价"}, "site": {"chat": {"title": "在线客服", "ariaLabel": "在线客服", "errorTitle": "客服窗口未加载", "loadingText": "正在连接在线客服...", "errorDescription": "请确认 ServiceBridge 用户端服务已启动", "initialUnreadCount": 1}, "email": "info@astreva.com", "phone": "", "cookie": {"text": "本网站使用 Cookie 以确保您在我们的网站上获得最佳体验、分析站点流量并协助我们的营销工作。", "title": "隐私与 Cookie 使用提示 :", "suffixText": "以了解更多信息或更改您的设置。", "privacyLabel": "隐私政策", "acceptAllLabel": "接受全部 Cookie", "necessaryLabel": "仅接受必要"}, "footer": {"logoAlt": "星渡ASTREVA 标志", "quickLinks": [{"href": "/", "label": "首页"}, {"href": "/products/", "label": "产品中心"}, {"href": "/about/", "label": "关于我们"}, {"href": "/solutions/", "label": "解决方案"}], "description": "建筑与市政排水领域的创新方案引领者。提供最高效、最模块化的不锈钢排水系统。", "socialTitle": "关注我们", "privacyLabel": "隐私政策", "supportLinks": [{"href": "/support/install/", "label": "安装指南"}, {"href": "/support/faq/", "label": "常见问题 (FAQs)"}, {"href": "/support/warranty/", "label": "售后与质保"}], "supportTitle": "服务支持", "agreementLabel": "用户协议", "quickLinksTitle": "快速链接", "socialEmptyText": "后台可配置社交媒体链接"}, "locale": "zh-CN", "logoUrl": "/assets/astreva-logo-transparent.png", "brandName": "星渡ASTREVA", "copyright": "@星渡ASTREVA 2026 版权所有.", "defaultSeo": {"image": "", "title": "星渡ASTREVA | 建筑与市政排水系统", "description": "星渡ASTREVA 提供模块化不锈钢排水沟、重型格栅、景观排水与工业排水系统。"}, "navigation": {"homeLabel": "首页", "aboutLabel": "关于我们", "productMenu": {"utilityLinks": [{"href": "/products/", "icon": "file", "label": "下载产品目录"}, {"href": "/support/install/", "icon": "book", "label": "查看选型指南"}, {"href": "/solutions/", "icon": "search", "label": "按应用场景查找"}, {"href": "/products/", "icon": "arrow", "label": "进入产品中心"}], "categoryLabel": "产品类别", "mobileToggleLabel": "展开产品分类", "popularSeriesLabel": "Popular Series", "popularSeriesTitleTemplate": "{category} · 热门系列", "viewAllCategoryLabelTemplate": "查看全部 {category} 产品"}, "supportLabel": "服务支持", "productsLabel": "产品中心", "solutionsLabel": "解决方案", "mobileMenuLabel": "打开导航"}, "socialIcons": {"tiktok": "TT", "twitter": "X", "youtube": "YT", "facebook": "F", "telegram": "TG", "whatsapp": "WA", "instagram": "IG"}, "socialLinks": {}, "brandTagline": "A Grate Innovation", "localization": {"arabicLabel": "العربية", "chineseLabel": "中文", "englishLabel": "English", "languageLabel": "语言", "switchingText": "切换中…", "switchAriaLabel": "切换网站语言", "unavailableText": "译文未就绪"}, "serviceBridgeUrl": "http://127.0.0.1:5173"}, "support": {"seo": {"title": "服务与支持 | 星渡ASTREVA", "description": "获取星渡ASTREVA 产品报价、技术支持、安装指南和售后质保服务。"}, "hero": {"title": "服务与支持", "description": "我们提供全方位的技术支持、安装指导与售后服务，确保您的项目万无一失。", "backgroundImage": "", "backgroundVideo": ""}, "contact": {"form": {"nameLabel": "您的姓名", "emailLabel": "电子邮箱", "phoneLabel": "联系电话", "submitLabel": "提交信息", "companyLabel": "公司或项目名称", "errorMessage": "提交失败，请通过电话或邮箱联系我们。", "messageLabel": "留言内容", "optionalLabel": "选填", "successMessage": "提交成功，我们会尽快联系您。", "namePlaceholder": "请输入姓名", "submittingLabel": "提交中...", "emailPlaceholder": "您的邮箱", "phonePlaceholder": "您的电话", "companyPlaceholder": "请输入公司或项目名称", "messagePlaceholder": "请描述您的项目需求或技术疑问...", "missingEndpointMessage": "后台接口尚未配置，请稍后再试。"}, "title": "联系我们", "emailIcon": "✉", "phoneIcon": "☎", "emailLabel": "企业邮箱", "phoneLabel": "销售咨询", "description": "无论您是需要索取报价，还是技术咨询，我们的专家团队都在这里准备为您服务。"}, "services": [{"cta": "查看保修政策", "href": "/support/warranty/", "icon": "盾", "title": "售后与质保", "description": "了解我们长达50年的超长使用寿命质保政策，以及专业的现场维护与售后检测服务。"}, {"cta": "查看安装手册", "href": "/support/install/", "icon": "工", "title": "安装指南", "description": "查看详细的视频教程与步骤指南，了解 Click咔哒锁扣的极致安装技巧与图纸规范。"}, {"cta": "浏览常见问题", "href": "/support/faq/", "icon": "?", "title": "常见问题 (FAQ)", "description": "快速寻找关于产品选型、承重标准、发货周期以及定制化需求的常见问题解答。"}]}, "products": [{"id": "prod_heavy_modular_stainless", "seo": {"title": "重型模块化不锈钢排水沟 | 星渡ASTREVA", "description": "适用于市政和公共工程的重型模块化不锈钢排水沟。"}, "body": "该系统不仅具备极致的耐腐蚀性和水力学性能，更能在最严苛的环境下提供长达 50 年的可靠服役周期。", "name": "重型模块化不锈钢排水沟", "slug": "heavy-modular-stainless-drain", "summary": "采用顶级 316/316L 不锈钢精密制造，结合专利 Click 咔哒锁扣技术。", "features": ["专利无缝拼接技术，100% 防渗漏", "符合 EN1433 国际承载标准", "一体成型结构，有效防止异物堵塞", "表面防滑处理，符合 ADA 建筑安全规范"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": true, "categorySlug": "municipal-public-works", "galleryImages": [], "specifications": [{"label": "主体材质", "value": "AISI 304 或 AISI 316L 级不锈钢"}, {"label": "内部宽度", "value": "100mm / 150mm / 200mm / 300mm"}, {"label": "承载等级", "value": "A15 - F900"}]}, {"id": "prod_municipal_grate", "seo": {"title": "高承载定制化市政格栅 | 星渡ASTREVA", "description": "高承载市政格栅和排水盖板定制方案。"}, "body": "适合高频交通和长期暴露环境，支持工程定制。", "name": "高承载定制化市政格栅", "slug": "high-load-custom-municipal-grate", "summary": "为市政道路和公共空间提供高承载、易维护的格栅系统。", "features": ["高承载结构", "快速检修", "耐腐蚀表面处理"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": true, "categorySlug": "municipal-public-works", "galleryImages": [], "specifications": [{"label": "承载等级", "value": "D400 - F900"}]}, {"id": "prod_slot_drain", "seo": {"title": "隐形缝隙式排水系统 | 星渡ASTREVA", "description": "用于商业与高端住宅的隐形缝隙式排水系统。"}, "body": "通过窄缝收水和模块化沟体兼顾美观与效率。", "name": "隐形缝隙式树脂排水系统", "slug": "invisible-slot-resin-drainage-system", "summary": "适合商业广场、高端住宅和景观地坪的低视觉干扰排水系统。", "features": ["隐形缝隙外观", "适配石材和地砖", "排水性能稳定"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": true, "categorySlug": "commercial-premium-residential", "galleryImages": [], "specifications": [{"label": "缝隙宽度", "value": "8mm / 12mm / 20mm"}]}, {"id": "prod_rain_collector", "seo": {"title": "景观级雨水收集器 | 星渡ASTREVA", "description": "适用于景观空间的雨水收集和排水节点。"}, "body": "让雨水管理与景观设计自然融合。", "name": "景观级雨水收集器", "slug": "landscape-rainwater-collector", "summary": "面向景观雨水组织与收集的建筑级节点产品。", "features": ["易清洁", "可定制面层", "与铺装协调"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "commercial-premium-residential", "galleryImages": [], "specifications": [{"label": "面层", "value": "不锈钢 / 石材嵌入式"}]}, {"id": "prod_industrial_channel", "seo": {"title": "防腐蚀工业级不锈钢明沟 | 星渡ASTREVA", "description": "工业级防腐不锈钢明沟排水系统。"}, "body": "适合食品、化工、物流和制造场景。", "name": "防腐蚀工业级不锈钢明沟", "slug": "anti-corrosion-industrial-stainless-channel", "summary": "为工业腐蚀环境和高强度清洗场景设计。", "features": ["316L 耐腐蚀", "卫生级焊接", "可承受高压冲洗"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": false, "categorySlug": "industrial-warehouse", "galleryImages": [], "specifications": [{"label": "材质", "value": "316L 不锈钢"}]}, {"id": "prod_industrial_cover", "seo": {"title": "工业级承重井盖 | 星渡ASTREVA", "description": "工业与仓储设施重载井盖产品。"}, "body": "根据场地荷载和检修频率定制。", "name": "工业级承重井盖", "slug": "industrial-heavy-duty-manhole-cover", "summary": "用于仓储、工业厂区和重型车辆区域的承重井盖。", "features": ["高承载", "防滑表面", "易维护开启"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "industrial-warehouse", "galleryImages": [], "specifications": [{"label": "承载", "value": "D400 - F900"}]}, {"id": "prod_curve_drain", "seo": {"title": "曲线定制地坪排水系统 | 星渡ASTREVA", "description": "曲线和异形地坪排水定制方案。"}, "body": "用于广场、公园、庭院和特殊建筑节点。", "name": "曲线定制地坪排水系统", "slug": "custom-curved-floor-drainage-system", "summary": "支持曲线、异形和复杂地坪边界的定制排水。", "features": ["曲线定制", "适合景观空间", "模块精确拼接"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": false, "categorySlug": "landscape-special-drainage", "galleryImages": [], "specifications": [{"label": "定制半径", "value": "按项目图纸加工"}]}, {"id": "prod_permeable_well", "seo": {"title": "生态透水材料与检查井 | 星渡ASTREVA", "description": "生态透水材料与检查井排水节点。"}, "body": "支持城市雨水滞蓄、渗透与排放的综合设计。", "name": "生态透水材料与检查井", "slug": "ecological-permeable-materials-and-inspection-well", "summary": "结合生态透水铺装和可维护检查井的雨水管理节点。", "features": ["生态透水", "检修便利", "适合海绵城市"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "landscape-special-drainage", "galleryImages": [], "specifications": [{"label": "应用", "value": "海绵城市 / 景观改造"}]}], "categories": [{"id": "cat_municipal", "seo": {"title": "市政与公共工程排水系统 | 星渡ASTREVA", "description": "适用于市政道路、公共广场和大型基础设施的模块化不锈钢排水方案。"}, "name": "市政与公共工程", "slug": "municipal-public-works", "heroVideo": "", "sortOrder": 10, "coverImage": "", "description": "面向道路、广场、公共设施的高承载排水系统。"}, {"id": "cat_commercial", "seo": {"title": "商业与高端住宅排水系统 | 星渡ASTREVA", "description": "服务商业综合体、高端住宅和景观空间的隐形排水系统。"}, "name": "商业与高端住宅", "slug": "commercial-premium-residential", "heroVideo": "", "sortOrder": 20, "coverImage": "", "description": "兼顾建筑美学、隐形排水与长期耐用性的高端场景方案。"}, {"id": "cat_industrial", "seo": {"title": "工业与仓储排水系统 | 星渡ASTREVA", "description": "用于工业厂房、仓储物流和重载区域的不锈钢排水产品。"}, "name": "工业与仓储设施", "slug": "industrial-warehouse", "heroVideo": "", "sortOrder": 30, "coverImage": "", "description": "适合重载、腐蚀和高频通行环境的工业排水系统。"}, {"id": "cat_landscape", "seo": {"title": "景观与特殊排水系统 | 星渡ASTREVA", "description": "用于景观、公园、庭院和异形地坪的定制排水解决方案。"}, "name": "景观与特殊排水", "slug": "landscape-special-drainage", "heroVideo": "", "sortOrder": 40, "coverImage": "", "description": "支持曲线、异形、生态透水和特殊节点的定制化排水。"}], "staticPages": [{"seo": {"title": "关于我们 | 星渡ASTREVA", "description": "了解星渡ASTREVA 的品牌、技术理念和排水系统创新。"}, "body": "<p>星渡ASTREVA 是全球领先的建筑与市政排水系统研发制造商。我们摒弃了传统的铸铁与水泥沟渠，开创性地推出了 <strong>100% 模块化的不锈钢 Click 咔哒锁扣系统</strong>。</p><p>我们的研发中心与制造基地配备了全球最先进的自动化生产线，确保每一寸不锈钢材都达到航天级精度。</p><h2>我们不仅制造产品，更在重构工程的标准。</h2><p>从商业广场的隐形缝隙，到市政重载道路的高强度格栅，星渡ASTREVA 以极致的耐腐蚀性、超过 50 年的超长使用寿命以及极致的安装速度，赢得了全球顶级建筑师和总包商的信赖。</p>", "hero": {"title": "推动全球排水创新的力量", "eyebrow": "About Us", "description": "自成立以来，星渡ASTREVA 始终致力于用前沿科技与顶级制造工艺，重塑建筑环境的生命线。", "backgroundImage": "", "backgroundVideo": ""}, "slug": "about", "title": "关于星渡ASTREVA", "sections": {"introIcon": "滴", "partnersTitle": "全球信赖的合作伙伴"}}, {"seo": {"title": "常见问题 | 星渡ASTREVA", "description": "查看星渡ASTREVA 排水系统的产品选型、定制、承载、交付和安装常见问题。"}, "body": "", "hero": {"title": "常见问题 (FAQs)", "description": "查看星渡ASTREVA 排水系统的产品选型、定制、承载、交付和安装常见问题。", "backgroundVideo": ""}, "slug": "faq", "title": "常见问题 (FAQs)", "sections": {"intro": ""}}, {"seo": {"title": "售后与质保政策 | 星渡ASTREVA", "description": "星渡ASTREVA 不锈钢排水系统质保政策和售后服务。"}, "body": "<p>在星渡ASTREVA，我们对产品的卓越品质充满信心。我们的不锈钢排水系统专为承受最严苛的环境而设计。</p><h3>1. 50年超长材料质保</h3><p>对于采用 316/316L 船用级不锈钢制造的核心排水模块，在正常使用和适当维护的情况下，我们提供长达 50 年的抗腐蚀和结构完整性质保。</p><h3>2. 性能与承载素质保证</h3><p>星渡ASTREVA 出厂的所有格栅与盖板均通过独立的第三方负载测试，符合全球主流承重等级。</p>", "hero": {"title": "售后与质保政策", "description": "星渡ASTREVA 不锈钢排水系统质保政策和售后服务。", "backgroundVideo": ""}, "slug": "warranty", "title": "售后与质保政策", "sections": {"icon": "盾"}}, {"seo": {"title": "安装指南 | 星渡ASTREVA", "description": "查看星渡ASTREVA Click 咔哒锁扣排水系统安装步骤。"}, "body": "<h3>Step 1 基础沟槽准备</h3><p>根据项目图纸要求，开挖具有足够宽度和深度的沟槽，并铺设混凝土垫层。</p><h3>Step 2 模块拼接与锁定</h3><p>将相邻两段星渡不锈钢排水沟模块对齐，通过专利 Click 锁扣机制实现无缝防水连接。</p><h3>Step 3 高度调节与固定</h3><p>利用沟体两侧自带的高度调节支架螺栓，将排水系统精确调整至标高水平面。</p>", "hero": {"title": "Click 咔哒锁扣系统 安装指南", "description": "查看星渡ASTREVA Click 咔哒锁扣排水系统安装步骤。", "backgroundVideo": ""}, "slug": "install", "title": "Click 咔哒锁扣系统 安装指南", "sections": {"icon": "工"}}, {"seo": {"title": "隐私政策 | 星渡ASTREVA", "description": "星渡ASTREVA 官网隐私政策。"}, "body": "<p>生效日期：2026年1月1日</p><p>星渡ASTREVA 高度重视您的隐私。本隐私政策解释了当您访问我们的网站或使用我们的服务时，我们如何收集、使用、披露和保护您的个人信息。</p><h3>信息收集</h3><p>当您通过我们的在线表单提交咨询、申请报价或订阅资讯时，我们可能会收集您的姓名、联系电话、电子邮件地址以及项目需求。</p>", "hero": {"title": "隐私政策", "description": "星渡ASTREVA 官网隐私政策。", "backgroundVideo": ""}, "slug": "privacy", "title": "隐私政策"}, {"seo": {"title": "用户服务协议 | 星渡ASTREVA", "description": "星渡ASTREVA 官网用户服务协议。"}, "body": "<p>感谢您访问星渡ASTREVA官方网站。在使用本网站之前，请仔细阅读以下条款和条件。</p><h3>网站内容与知识产权</h3><p>本网站上的所有内容均受版权法保护，未经书面许可，任何人不得出于商业目的复制、分发或修改这些资料。</p><h3>产品信息免责声明</h3><p>具体工程参数应以我们的工程师为您出具的最终正式方案及技术协议为准。</p>", "hero": {"title": "用户服务协议", "description": "星渡ASTREVA 官网用户服务协议。", "backgroundVideo": ""}, "slug": "agreement", "title": "用户服务协议"}, {"seo": {"title": "解决方案 | 星渡ASTREVA", "description": "浏览星渡ASTREVA 市政、商业、工业、景观、海绵城市等排水系统解决方案。"}, "body": "", "hero": {"title": "面向真实场景的\\n系统化排水方案", "eyebrow": "Solutions", "subtitle": "围绕市政、商业、工业、景观等场景，提供从产品选型到落地安装的完整方案。", "description": "从水力模型计算、承载等级评估到材料化学性能匹配，星渡ASTREVA 不仅提供排水沟，更提供应对极端环境的工程确定性。", "backgroundImage": "", "backgroundVideo": ""}, "slug": "solutions", "title": "解决方案", "sections": {"ctaHref": "/support/", "ctaIcon": "→", "ctaLabel": "查看详细技术手册", "bulletIcon": "✓", "detailNote": "具体规格与安装条件请联系星渡技术团队确认。", "introTitle": "按应用场景选择方案", "adviceTitle": "需要专业选型建议？", "featureIcon": "✓", "systemCards": [{"step": "Step 01. 窄缝收水", "title": "仅 10-20mm 的缝隙，完美隐藏于石材缝隙中。"}, {"step": "Step 02. 高强沟体", "title": "U 型光滑底部提供超高自净流速，减少淤积。"}, {"step": "Step 03. 隐藏式检修", "title": "专利检修口盖板可填充同色石材，实现 100% 视觉统一。"}], "sideNavTitle": "方案导航", "videoPlayIcon": "▶", "introDescription": "围绕真实工程条件拆解排水系统，从承载、材质、坡度、维护和视觉效果完成完整选型。", "solutionSections": [{"id": "sol-sec-1", "image": "", "title": "市政道路与城市公共广场", "number": "01", "bullets": ["满足 EN1433 标准 F900 最高承载要求", "抗沉降设计，防止路面衔接处断裂", "极速排水模型计算，应对 50 年一遇暴雨"], "ctaHref": "", "ctaLabel": "", "navLabel": "市政道路排水", "videoUrl": "", "detailNote": "具体规格与安装条件请联系星渡技术团队确认。", "focusTitle": "核心解决：结构稳定性", "videoImage": "", "description": "针对城市主干道、交通枢纽及大型公共广场，排水系统面临的首要挑战是高频率载荷与突发性强降水。星渡 F900 级模块化系统专为此设计。", "videoCaption": "安装与承载能力视频：F900 承载不锈钢系统在城市枢纽的安装演示", "focusDescription": "采用不锈钢一体化预制沟体，替代传统现浇沟渠。其物理特性保证了在重载碾压下不会产生混凝土剥落或缝隙扩大的风险。Click 锁扣系统确保了长距离安装的一致性。"}, {"id": "sol-sec-2", "title": "商业综合体与五星级酒店", "number": "02", "bullets": ["仅 10-20mm 窄缝收水，隐藏于石材缝隙", "U 型光滑底部提供高自净流速", "隐藏式检修口可填充同色石材，实现视觉统一"], "ctaHref": "/support/", "ctaLabel": "查看详细技术手册", "navLabel": "商业综合体", "detailNote": "具体规格与安装条件请联系星渡技术团队确认。", "focusTitle": "美学与性能的终极平衡", "description": "商业环境不仅要求功能卓越，更要求视觉隐形。排水系统必须与高端石材铺装完美融合，同时满足高人流量下的安全性与维护便捷性。", "focusDescription": "星渡隐形排水系统可应用于高端商业与酒店项目。我们提供完整的 BIM 适配图纸，确保在设计阶段即可完成铺装模数对齐。"}, {"id": "sol-sec-3", "image": "", "title": "工业厂房与洁净室排水", "number": "03", "bullets": ["316L 不锈钢材质，耐强酸强碱清洗环境", "符合 HACCP 要求的圆角设计", "适配重型叉车频繁转向的高强格栅"], "ctaHref": "", "ctaLabel": "", "navLabel": "工业与洁净", "detailNote": "具体规格与安装条件请联系星渡技术团队确认。", "focusTitle": "抗腐蚀与无卫生死角", "description": "在食品、医药生产车间，排水系统是污染控制的核心。星渡工业级全不锈钢明沟系统采用镜面抛光处理，支持 CIP 在位清洗。", "focusDescription": "316L 不锈钢材质适应强酸强碱清洗环境，圆角沟底降低污垢残留，适合洁净厂房、食品加工和高频冲洗区域。"}, {"id": "sol-sec-4", "image": "", "title": "高端景观与异形地坪定制", "number": "04", "bullets": ["支持曲线、折线和非标尺寸定制", "可与石材、砖材、金属面层协调", "隐藏检修节点，兼顾维护和美观"], "ctaHref": "", "ctaLabel": "", "navLabel": "高端景观定制", "detailNote": "具体规格与安装条件请联系星渡技术团队确认。", "focusTitle": "让排水系统融入铺装语言", "description": "面对曲线铺装、庭院水景、商业街区与高端住宅庭院，排水系统既要隐藏，又要顺应复杂边界。星渡支持弧形、异形和节点级定制。", "focusDescription": "通过定制曲率、缝隙宽度和检修节点，排水沟可以成为铺装分缝的一部分，而不是破坏景观完整性的突兀构件。"}, {"id": "sol-sec-5", "image": "", "title": "海绵城市与生态雨水利用", "number": "05", "bullets": ["适配海绵城市节点和生态铺装", "支持雨水收集、检查与维护", "可与景观排水和市政管网衔接"], "ctaHref": "", "ctaLabel": "", "navLabel": "海绵城市/生态", "detailNote": "具体规格与安装条件请联系星渡技术团队确认。", "focusTitle": "从快速排水到雨水管理", "description": "面向公园、绿地、城市更新和生态街区，星渡将排水、滞蓄、检查与维护节点整合进可持续雨水管理系统。", "focusDescription": "生态透水材料、雨水收集器和检查井节点可组合使用，帮助项目在暴雨应对、维护检修和可持续认证之间取得平衡。"}], "advicePrimaryHref": "/support/", "architectureTitle": "隐形缝隙式系统架构", "advicePrimaryLabel": "咨询方案专家", "adviceSecondaryHref": "/products/", "adviceSecondaryLabel": "下载全线目录"}}], "productCenter": {"seo": {"title": "产品中心 | 星渡ASTREVA", "description": "按应用场景浏览星渡ASTREVA 模块化排水系统、格栅、井盖和景观排水产品。"}, "hero": {"title": "产品中心", "description": "探索我们的系统在各核心领域的应用，选择您的业务板块以查看专属方案。", "backgroundImage": "", "backgroundVideo": ""}, "intro": {"title": "请选择应用场景与业务板块", "description": "我们将为您精确匹配最合适的系统解决方案", "categoryCtaLabel": "查看相关产品"}, "catalog": {"eyebrow": "Product Center", "description": "按产品类型快速查找专业不锈钢排水产品与系统组件。", "viewAllLabel": "查看全部", "categoriesTitle": "产品分类", "categoriesEyebrow": "Product Categories", "categoriesAriaLabel": "产品分类", "emptyCategoryMessage": "该分类的系列产品正在整理中。", "categoriesDescription": "选择左侧产品体系，查看对应系列产品与组件。"}, "detailPage": {"badgeIcon": "✓", "badgeLabel": "顶级工业品质", "specsTitle": "技术规格与参数", "videoTitle": "产品视频", "featureIcon": "✓", "galleryTitle": "产品图库", "descriptionIcon": "工", "quoteButtonIcon": "✉", "descriptionTitle": "产品说明", "quoteButtonLabel": "获取项目报价", "specsDescription": "标准化模块化尺寸，亦支持根据项目需求进行深度定制。", "specsPrimaryIcon": "层", "specsPrimaryTitle": "材质与工艺", "downloadButtonIcon": "↓", "breadcrumbSeparator": "›"}, "categoryPage": {"backIcon": "←", "backLabel": "返回重新选择业务板块", "titleTemplate": "{category} - 专属产品方案", "categoryCtaIcon": "→", "productHoverLabel": "查看详情"}}}	1	2026-08-28 03:53:02.684321+00
\.


--
-- Data for Name: site_content_translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_content_translations (locale, content, source_revision, status, last_error, started_at, finished_at, created_at, updated_at) FROM stdin;
ar	{"faqs": [{"id": "faq_custom", "answer": "بالتأكيد. بالإضافة إلى الوحدات القياسية، يمكن لفريقنا الهندسي تصميم أنظمة تصريف من الفولاذ المقاوم للصدأ بأشكال غير منتظمة ومنحنية وبعروض خاصة، وذلك وفقًا لطبيعة الموقع والتدفق الهيدروليكي ومتحنيات المناسيب الخاصة بكم.", "enabled": true, "question": "هل تدعم أنظمة التصريف لديكم التخصيص؟", "sortOrder": 10}, {"id": "faq_click", "answer": "قنوات التصريف التقليدية المصنوعة من الخرسانة الراتنجية أو الطوب ثقيلة جدًا وتتطلب أعمال تلييس معقدة أو لحامًا ميدانيًا. نظام Click الخاص بنا لا يتجاوز وزنه خُمس الوزن التقليدي، ويأتي مزودًا بمشابك ميكانيكية متشابكة مقاومة للماء، مما يلغي تمامًا الحاجة إلى اللحام ووقت انتظار التصلب — تركيب فوري بمجرد التجميع.", "enabled": true, "question": "لماذا يُعد نظام Click أسرع بكثير في التركيب مقارنة بقنوات التصريف التقليدية؟", "sortOrder": 20}, {"id": "faq_load", "answer": "نعم. طرازاتنا المخصصة للأحمال الثقيلة تتوافق مع المعيار الأوروبي EN1433 من الفئة F900، وتتحمل الأحمال القصوى في مدارج المطارات ومستودعات الخدمات اللوجستية الثقيلة.", "enabled": true, "question": "هل تتحمل المنتجات مرور الشاحنات الثقيلة؟", "sortOrder": 30}, {"id": "faq_delivery", "answer": "بالنسبة للطرازات والأطوال القياسية، نمتلك مخزونًا كافيًا يتيح الشحن خلال 3 إلى 5 أيام عمل. أما في حال الأنظمة الهندسية المخصصة بدرجة عالية، فتتراوح مدة الإنتاج عادةً بين 2 إلى 4 أسابيع.", "enabled": true, "question": "ما هي مدة التوريد المعتادة؟", "sortOrder": 40}], "home": {"cta": {"title": "هل تخطط لمشروعك القادم؟", "description": "إذا كنت تبحث عن نظام تصريف فعّال وأنيق ومتين، فتواصل الآن مع فريقنا الهندسي المتخصص للحصول على عرض أسعار مجاني.", "primaryHref": "/support/", "primaryLabel": "تواصل معنا الآن", "secondaryHref": "/products/", "secondaryLabel": "تحميل كتالوج المنتجات", "backgroundImage": ""}, "seo": {"title": "ASTREVA | أنظمة تصريف معيارية من الفولاذ المقاوم للصدأ", "description": "حلول مبتكرة في مجال تصريف المباني والبلديات، متخصصة في أنظمة تصريف معيارية من الفولاذ المقاوم للصدأ تجمع بين الكفاءة والأناقة والمتانة."}, "hero": {"title": "ASTREVA", "eyebrow": "أسرع نظام تصريف. بكل تأكيد.", "subtitle": "حلول مبتكرة في مجال الصرف الصحي للمباني والبلديات", "videoUrl": "https://youtube.com/shorts/XhHzoY3kG54?feature=share", "trademark": "TM", "primaryCta": "استكشف المنتجات", "videoTitle": "فيديو ترويجي لـ ASTREVA", "primaryHref": "/products/", "secondaryCta": "تشغيل الفيديو", "backgroundImage": "", "backgroundVideo": "", "videoCloseLabel": "إغلاق الفيديو", "videoPreviewLabel": "مشغّل الفيديو الترويجي (معاينة)", "videoOpenExternalLabel": "لا يمكن التشغيل؟ افتح على YouTube"}, "partners": ["LANDLEASE", "LA SIMON BUILDERS", "MA CIVIL DESIGN", "MULTIPLEX", "BESIX Watpac"], "advantages": [{"icon": "▶", "title": "تركيب فائق السرعة", "description": "نظام قفل Click الحاصل على براءة اختراع، تركيب في ثانية واحدة."}, {"icon": "✓", "title": "متانة فائقة", "description": "ضمان عمر افتراضي يصل إلى 50 عامًا."}, {"icon": "工", "title": "قدرة تحمل استثنائية", "description": "اجتاز اختبار تحمل الأحمال من الفئة Class G، مناسب للمناطق ذات الأحمال الثقيلة."}, {"icon": "滴", "title": "مواد صديقة للبيئة", "description": "فولاذ مقاوم للصدأ قابل لإعادة التدوير بنسبة 100%، يدعم الحصول على شهادة LEED."}], "partnerLabel": "شركاؤنا:", "productIntro": {"image": "", "title": "ما هي منتجاتنا؟", "bullets": ["تصميم معياري بنسبة 100%، يقلّل مدة التنفيذ بنسبة 80%", "مواد خفيفة الوزن تُقلّل تكاليف النقل والعمالة", "تجميع بدون فواصل، يمنع التسرب تمامًا", "مظهر معماري أنيق يتناسب مع جميع أنواع الأرضيات"], "ctaHref": "/products/", "ctaLabel": "عرض المواصفات الفنية", "bulletIcon": "✓", "description": "تلتزم ASTREVA بتطوير وإنتاج أسرع أنظمة الصرف المعياري وأكثرها موثوقية في العالم. لقد تخلّينا عن قنوات الصرف التقليدية الثقيلة، واستبدلناها بنظام تجميع فوري مصنوع من الفولاذ المقاوم للصدأ عالي المتانة."}, "testimonials": [], "advantagesIntro": {"title": "اكتشف مزايا منتجاتنا", "description": "لماذا يختار كبار المقاولين والمهندسين المعماريين حول العالم ASTREVA؟"}, "featuredProducts": {"title": "عرض المنتجات", "linkIcon": "→", "linkLabel": "اعرف المزيد", "description": "استكشف مجموعتنا الكاملة من منتجات الصرف عالية الأداء، المصممة خصيصًا لتلبية مختلف احتياجات البناء والبلديات."}, "testimonialsTitle": "ماذا يقول عملاؤنا"}, "site": {"chat": {"title": "الدعم المباشر", "ariaLabel": "الدعم المباشر", "errorTitle": "تعذّر تحميل نافذة الدعم", "loadingText": "جارٍ الاتصال بخدمة العملاء المباشرة...", "errorDescription": "يرجى التأكد من تشغيل خدمة عميل ServiceBridge", "initialUnreadCount": 1}, "email": "info@astreva.com", "phone": "", "cookie": {"text": "يستخدم هذا الموقع ملفات تعريف الارتباط (Cookie) لضمان حصولك على أفضل تجربة على موقعنا، وتحليل حركة المرور على الموقع، ودعم جهودنا التسويقية.", "title": "إشعار الخصوصية واستخدام ملفات تعريف الارتباط:", "suffixText": "لمعرفة المزيد من المعلومات أو تغيير إعداداتك.", "privacyLabel": "سياسة الخصوصية", "acceptAllLabel": "قبول جميع ملفات تعريف الارتباط", "necessaryLabel": "قبول الضروري فقط"}, "footer": {"logoAlt": "شعار ASTREVA", "quickLinks": [{"href": "/", "label": "الرئيسية"}, {"href": "/products/", "label": "مركز المنتجات"}, {"href": "/about/", "label": "من نحن"}, {"href": "/solutions/", "label": "الحلول"}], "description": "رائد الحلول المبتكرة في مجال تصريف المباني والبلديات. نُقدّم أكثر أنظمة التصريف من الفولاذ المقاوم للصدأ كفاءةً ومرونةً.", "socialTitle": "تابعونا", "privacyLabel": "سياسة الخصوصية", "supportLinks": [{"href": "/support/install/", "label": "دليل التثبيت"}, {"href": "/support/faq/", "label": "الأسئلة الشائعة (FAQs)"}, {"href": "/support/warranty/", "label": "خدمة ما بعد البيع والضمان"}], "supportTitle": "الدعم الفني", "agreementLabel": "اتفاقية المستخدم", "quickLinksTitle": "روابط سريعة", "socialEmptyText": "يمكن تكوين روابط وسائل التواصل الاجتماعي من لوحة التحكم"}, "locale": "ar", "logoUrl": "/assets/astreva-logo-transparent.png", "brandName": "أستريفا ASTREVA", "copyright": "@星渡ASTREVA 2026 جميع الحقوق محفوظة.", "defaultSeo": {"image": "", "title": "星渡ASTREVA | أنظمة الصرف للمباني والبلديات", "description": "توفر 星渡ASTREVA قنوات صرف معيارية من الفولاذ المقاوم للصدأ، وشبكات ثقيلة، وأنظمة صرف للمناظر الطبيعية والصناعة."}, "navigation": {"homeLabel": "الرئيسية", "aboutLabel": "من نحن", "productMenu": {"utilityLinks": [{"href": "/products/", "icon": "file", "label": "تحميل كتالوج المنتجات"}, {"href": "/support/install/", "icon": "book", "label": "عرض دليل الاختيار"}, {"href": "/solutions/", "icon": "search", "label": "البحث حسب مجال التطبيق"}, {"href": "/products/", "icon": "arrow", "label": "الدخول إلى مركز المنتجات"}], "categoryLabel": "فئات المنتجات", "mobileToggleLabel": "توسيع تصنيفات المنتجات", "popularSeriesLabel": "Popular Series", "popularSeriesTitleTemplate": "{category} · السلاسل الشائعة", "viewAllCategoryLabelTemplate": "عرض جميع منتجات {category}"}, "supportLabel": "الدعم والخدمات", "productsLabel": "مركز المنتجات", "solutionsLabel": "الحلول", "mobileMenuLabel": "فتح قائمة التنقل"}, "socialIcons": {"tiktok": "TT", "twitter": "X", "youtube": "YT", "facebook": "F", "telegram": "TG", "whatsapp": "WA", "instagram": "IG"}, "socialLinks": {}, "brandTagline": "A Grate Innovation", "localization": {"arabicLabel": "العربية", "chineseLabel": "الصينية", "englishLabel": "English", "languageLabel": "اللغة", "switchingText": "جارٍ التبديل…", "switchAriaLabel": "تبديل لغة الموقع", "unavailableText": "الترجمة غير متوفرة بعد"}, "serviceBridgeUrl": "http://127.0.0.1:5173"}, "support": {"seo": {"title": "الخدمة والدعم | ASTREVA", "description": "احصل على عروض أسعار منتجات ASTREVA والدعم الفني وأدلة التركيب وخدمات الضمان."}, "hero": {"title": "الخدمات والدعم", "description": "نقدّم دعمًا فنيًا شاملًا، وإرشادات التثبيت، وخدمات ما بعد البيع لضمان نجاح مشروعك دون أي مخاطر.", "backgroundImage": "", "backgroundVideo": ""}, "contact": {"form": {"nameLabel": "الاسم الكامل", "emailLabel": "البريد الإلكتروني", "phoneLabel": "رقم الهاتف", "submitLabel": "إرسال", "companyLabel": "اسم الشركة أو المشروع", "errorMessage": "فشل الإرسال، يرجى التواصل معنا عبر الهاتف أو البريد الإلكتروني.", "messageLabel": "محتوى الرسالة", "optionalLabel": "اختياري", "successMessage": "تم الإرسال بنجاح، سنتواصل معك في أقرب وقت ممكن.", "namePlaceholder": "يرجى إدخال الاسم", "submittingLabel": "جارٍ الإرسال...", "emailPlaceholder": "بريدك الإلكتروني", "phonePlaceholder": "رقم هاتفك", "companyPlaceholder": "يرجى إدخال اسم الشركة أو المشروع", "messagePlaceholder": "يرجى وصف متطلبات مشروعك أو استفساراتك التقنية...", "missingEndpointMessage": "لم يتم تكوين واجهة الخادم بعد، يُرجى المحاولة مرة أخرى لاحقًا."}, "title": "اتصل بنا", "emailIcon": "✉", "phoneIcon": "☎", "emailLabel": "البريد الإلكتروني للشركة", "phoneLabel": "استشارات المبيعات", "description": "سواء كنت بحاجة إلى طلب عرض أسعار أو استشارة تقنية، فإن فريقنا من الخبراء على أتم الاستعداد لخدمتك."}, "services": [{"cta": "عرض سياسة الضمان", "href": "/support/warranty/", "icon": "盾", "title": "خدمة ما بعد البيع والضمان", "description": "تعرّف على سياسة الضمان التي تصل إلى 50 عامًا من العمر الافتراضي، بالإضافة إلى خدمات الصيانة الميدانية الاحترافية والفحص ما بعد البيع."}, {"cta": "عرض دليل التركيب", "href": "/support/install/", "icon": "工", "title": "دليل التركيب", "description": "اطّلع على الدروس التعليمية المصوّرة والأدلة التفصيلية خطوة بخطوة، وتعرّف على أفضل تقنيات التركيب لنظام قفل Click والمواصفات الهندسية للرسومات."}, {"cta": "تصفّح الأسئلة الشائعة", "href": "/support/faq/", "icon": "?", "title": "الأسئلة الشائعة (FAQ)", "description": "ابحث بسرعة عن إجابات حول اختيار المنتجات، ومعايير تحمّل الأحمال، ومدد الشحن، ومتطلبات التخصيص."}]}, "products": [{"id": "prod_heavy_modular_stainless", "seo": {"title": "قنوات تصريف معيارية من الفولاذ المقاوم للصدأ شديدة التحمل | ASTREVA", "description": "قنوات تصريف معيارية من الفولاذ المقاوم للصدأ للاستخدام الشاق، مخصصة للمشاريع البلدية والأشغال العامة."}, "body": "لا يقتصر هذا النظام على مقاومة التآكل الفائقة والأداء الهيدروليكي المتميز فحسب، بل يوفر أيضًا دورة خدمة موثوقة تصل إلى 50 عامًا في أقسى الظروف البيئية.", "name": "قنوات تصريف معيارية من الفولاذ المقاوم للصدأ للاستخدام الشاق", "slug": "heavy-modular-stainless-drain", "summary": "مصنّعة بدقة من الفولاذ المقاوم للصدأ 316/316L عالي الجودة، مع تقنية قفل Click الحاصلة على براءة اختراع.", "features": ["تقنية توصيل سلس حاصلة على براءة اختراع، مانعة للتسرب بنسبة 100%", "متوافقة مع معيار التحمل الدولي EN1433", "هيكل مصبوب بقطعة واحدة، يمنع انسداد الأجسام الغريبة بفعالية", "معالجة سطح مضادة للانزلاق، متوافقة مع معايير ADA لسلامة المباني"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": true, "categorySlug": "municipal-public-works", "galleryImages": [], "specifications": [{"label": "المادة الرئيسية", "value": "فولاذ مقاوم للصدأ من الدرجة AISI 304 أو AISI 316L"}, {"label": "العرض الداخلي", "value": "100mm / 150mm / 200mm / 300mm"}, {"label": "فئة التحمل", "value": "A15 - F900"}]}, {"id": "prod_municipal_grate", "seo": {"title": "شبكات بلدية مخصصة عالية التحمل | ASTREVA", "description": "حلول مخصصة للشبكات البلدية عالية التحمل وأغطية الصرف."}, "body": "مناسبة لحركة المرور الكثيفة والبيئات المعرضة للعوامل الجوية على المدى الطويل، مع دعم التخصيص الهندسي.", "name": "شبكات بلدية مخصصة عالية التحمل", "slug": "high-load-custom-municipal-grate", "summary": "أنظمة شبكات ذات قدرة تحمل عالية وسهلة الصيانة، مصمّمة للطرق البلدية والمساحات العامة.", "features": ["هيكل عالي التحمل", "وصول سريع للصيانة", "معالجة سطحية مقاومة للتآكل"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": true, "categorySlug": "municipal-public-works", "galleryImages": [], "specifications": [{"label": "فئة التحمل", "value": "D400 - F900"}]}, {"id": "prod_slot_drain", "seo": {"title": "نظام التصريف الخطي المخفي | ASTREVA", "description": "نظام تصريف خطي مخفي للمشاريع التجارية والسكنية الفاخرة."}, "body": "يجمع بين الجمال والكفاءة من خلال فتحات ضيقة لجمع المياه وقنوات معيارية متكاملة.", "name": "نظام تصريف راتنجي بتصميم الشق المخفي", "slug": "invisible-slot-resin-drainage-system", "summary": "نظام تصريف منخفض التأثير البصري، مناسب للساحات التجارية والمساكن الراقية وأرضيات المناظر الطبيعية.", "features": ["تصميم الشق المخفي", "متوافق مع الأحجار والبلاط", "أداء تصريف مستقر"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": true, "categorySlug": "commercial-premium-residential", "galleryImages": [], "specifications": [{"label": "عرض الفتحة", "value": "8mm / 12mm / 20mm"}]}, {"id": "prod_rain_collector", "seo": {"title": "مجمّع مياه الأمطار للمناظر الطبيعية | ASTREVA", "description": "نقاط تجميع وتصريف مياه الأمطار المصممة للمساحات الطبيعية."}, "body": "دمج إدارة مياه الأمطار مع تصميم المناظر الطبيعية بسلاسة.", "name": "مجمّع مياه الأمطار بتصميم المناظر الطبيعية", "slug": "landscape-rainwater-collector", "summary": "منتجات معمارية من الدرجة الأولى لتنظيم وجمع مياه الأمطار في المناظر الطبيعية.", "features": ["سهل التنظيف", "سطح قابل للتخصيص", "متناسق مع الرصف"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "commercial-premium-residential", "galleryImages": [], "specifications": [{"label": "السطح", "value": "فولاذ مقاوم للصدأ / مدمج بالحجر"}]}, {"id": "prod_industrial_channel", "seo": {"title": "قنوات تصريف مفتوحة من الفولاذ المقاوم للصدأ بدرجة صناعية مقاومة للتآكل | ASTREVA", "description": "نظام تصريف بقنوات مفتوحة من الفولاذ المقاوم للصدأ بدرجة صناعية مقاوم للتآكل."}, "body": "مناسب لقطاعات الأغذية والكيماويات والخدمات اللوجستية والتصنيع.", "name": "قنوات تصريف مفتوحة من الفولاذ المقاوم للصدأ بدرجة صناعية مقاومة للتآكل", "slug": "anti-corrosion-industrial-stainless-channel", "summary": "مصممة للبيئات الصناعية المسببة للتآكل وسيناريوهات التنظيف عالي الضغط.", "features": ["مقاومة للتآكل بدرجة 316L", "لحام بدرجة صحية", "تتحمل الغسيل بالضغط العالي"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": false, "categorySlug": "industrial-warehouse", "galleryImages": [], "specifications": [{"label": "المادة", "value": "فولاذ مقاوم للصدأ 316L"}]}, {"id": "prod_industrial_cover", "seo": {"title": "أغطية فتحات التفتيش الصناعية عالية التحمل | شينغدو ASTREVA", "description": "منتجات أغطية فتحات التفتيش عالية التحمل للمنشآت الصناعية والمستودعات."}, "body": "تُصمَّم خصيصًا وفقًا لحمل الموقع وتكرار الصيانة.", "name": "غطاء فتحة تفتيش صناعي عالي التحمل", "slug": "industrial-heavy-duty-manhole-cover", "summary": "أغطية فتحات تفتيش عالية التحمل للمستودعات والمناطق الصناعية ومناطق المركبات الثقيلة.", "features": ["قدرة تحمل عالية", "سطح مقاوم للانزلاق", "فتح سهل للصيانة"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "industrial-warehouse", "galleryImages": [], "specifications": [{"label": "قدرة التحمل", "value": "D400 - F900"}]}, {"id": "prod_curve_drain", "seo": {"title": "نظام تصريف أرضيات مخصص منحني | ASTREVA", "description": "حلول مخصصة لتصريف الأرضيات المنحنية وغير المنتظمة."}, "body": "للساحات والحدائق والأفنية والعقد المعمارية الخاصة.", "name": "نظام تصريف أرضيات مخصص منحني", "slug": "custom-curved-floor-drainage-system", "summary": "يدعم التصريف المخصص للحدود الأرضية المنحنية وغير المنتظمة والمعقدة.", "features": ["تصميم منحنيات مخصص", "مناسبة للمساحات الطبيعية", "تجميع دقيق للوحدات"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": false, "categorySlug": "landscape-special-drainage", "galleryImages": [], "specifications": [{"label": "نصف قطر مخصص", "value": "التصنيع وفقًا لمخططات المشروع"}]}, {"id": "prod_permeable_well", "seo": {"title": "المواد النفاذة البيئية وغرف التفتيش | ASTREVA", "description": "عقد تصريف المواد النفاذة البيئية وغرف التفتيش."}, "body": "تصميم متكامل يدعم احتجاز مياه الأمطار الحضرية وتسربها وتصريفها.", "name": "مواد النفاذية البيئية وآبار التفتيش", "slug": "ecological-permeable-materials-and-inspection-well", "summary": "عقد إدارة مياه الأمطار التي تجمع بين الرصف النفاذ البيئي وآبار التفتيش القابلة للصيانة.", "features": ["نفاذية بيئية", "سهولة الصيانة", "مناسب للمدن الإسفنجية"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "landscape-special-drainage", "galleryImages": [], "specifications": [{"label": "التطبيق", "value": "المدن الإسفنجية / تجديد المناظر الطبيعية"}]}], "categories": [{"id": "cat_municipal", "seo": {"title": "أنظمة الصرف للأشغال البلدية والعامة | ASTREVA", "description": "حلول تصريف معيارية من الفولاذ المقاوم للصدأ مناسبة للطرق البلدية والساحات العامة والبنية التحتية واسعة النطاق."}, "name": "المشاريع البلدية والعامة", "slug": "municipal-public-works", "heroVideo": "", "sortOrder": 10, "coverImage": "", "description": "أنظمة تصريف عالية التحمل مصممة للطرق والساحات والمرافق العامة."}, {"id": "cat_commercial", "seo": {"title": "أنظمة تصريف للمشاريع التجارية والسكنية الفاخرة | ASTREVA", "description": "أنظمة تصريف مخفية تخدم المجمعات التجارية والمساكن الفاخرة والمساحات الطبيعية."}, "name": "المشاريع التجارية والسكنية الفاخرة", "slug": "commercial-premium-residential", "heroVideo": "", "sortOrder": 20, "coverImage": "", "description": "حلول متقدمة تجمع بين الجمال المعماري والتصريف المخفي والمتانة طويلة الأمد."}, {"id": "cat_industrial", "seo": {"title": "أنظمة تصريف للمناطق الصناعية والمستودعات | ASTREVA", "description": "منتجات تصريف من الفولاذ المقاوم للصدأ للمصانع الصناعية ومرافق التخزين واللوجستيات ومناطق الأحمال الثقيلة."}, "name": "المنشآت الصناعية ومرافق التخزين", "slug": "industrial-warehouse", "heroVideo": "", "sortOrder": 30, "coverImage": "", "description": "أنظمة تصريف صناعية مصممة لبيئات الأحمال الثقيلة والتآكل وحركة المرور المكثفة."}, {"id": "cat_landscape", "seo": {"title": "أنظمة تصريف المناظر الطبيعية والتصريف الخاص | شينغدو ASTREVA", "description": "حلول تصريف مخصصة للمناظر الطبيعية والحدائق والأفنية والأرضيات ذات الأشكال غير المنتظمة."}, "name": "تصريف المناظر الطبيعية والتصريف الخاص", "slug": "landscape-special-drainage", "heroVideo": "", "sortOrder": 40, "coverImage": "", "description": "تصريف مخصص يدعم المنحنيات والأشكال غير المنتظمة والنفاذية البيئية والتفاصيل الخاصة."}], "staticPages": [{"seo": {"title": "من نحن | شينغدو ASTREVA", "description": "تعرّف على علامة ASTREVA التجارية وفلسفتها التقنية وابتكاراتها في أنظمة الصرف."}, "body": "<p>ASTREVA هي شركة رائدة عالميًا في مجال البحث والتطوير والتصنيع لأنظمة الصرف المعمارية والبلدية. لقد تخلينا عن القنوات التقليدية المصنوعة من الحديد الزهر والأسمنت، وأطلقنا بشكل مبتكر <strong>نظام القفل بنقرة Click المعياري من الفولاذ المقاوم للصدأ بنسبة 100%</strong>.</p><p>مركزنا للبحث والتطوير وقاعدة التصنيع لدينا مجهّزان بأكثر خطوط الإنتاج الآلية تقدمًا في العالم، مما يضمن أن كل بوصة من الفولاذ المقاوم للصدأ تحقق دقة بمستوى صناعة الطيران.</p><h2>نحن لا نصنع المنتجات فحسب، بل نعيد تشكيل معايير الهندسة.</h2><p>من الفواصل المخفية في الساحات التجارية إلى الشبكات عالية التحمل للطرق البلدية ذات الأحمال الثقيلة، اكتسبت ASTREVA ثقة كبار المهندسين المعماريين والمقاولين العامين حول العالم بفضل مقاومتها الفائقة للتآكل، وعمرها الافتراضي الذي يتجاوز 50 عامًا، وسرعة تركيبها الاستثنائية.</p>", "hero": {"title": "القوة الدافعة لابتكارات الصرف حول العالم", "eyebrow": "About Us", "description": "منذ تأسيسها، تلتزم ASTREVA بإعادة تشكيل شريان الحياة في البيئة المعمارية من خلال التقنيات المتطورة وأعلى معايير التصنيع.", "backgroundImage": "", "backgroundVideo": ""}, "slug": "about", "title": "عن ASTREVA", "sections": {"introIcon": "قطرة", "partnersTitle": "شركاء موثوق بهم عالميًا"}}, {"seo": {"title": "الأسئلة الشائعة | ASTREVA", "description": "اطّلع على الأسئلة الشائعة حول اختيار المنتجات والتخصيص وتحمل الأحمال والتسليم والتركيب لأنظمة تصريف المياه من ASTREVA."}, "body": "", "hero": {"title": "الأسئلة الشائعة (FAQs)", "description": "اطّلع على الأسئلة الشائعة حول اختيار المنتجات والتخصيص وتحمل الأحمال والتسليم والتركيب لأنظمة تصريف المياه من ASTREVA.", "backgroundVideo": ""}, "slug": "faq", "title": "الأسئلة الشائعة (FAQs)", "sections": {"intro": ""}}, {"seo": {"title": "سياسة الضمان وخدمة ما بعد البيع | ASTREVA", "description": "سياسة الضمان وخدمة ما بعد البيع لأنظمة تصريف المياه من الفولاذ المقاوم للصدأ من ASTREVA."}, "body": "<p>في ASTREVA، نحن واثقون تمامًا من الجودة الاستثنائية لمنتجاتنا. أنظمة تصريف المياه من الفولاذ المقاوم للصدأ لدينا مصممة خصيصًا لتحمل أقسى البيئات.</p><h3>1. ضمان مواد استثنائي لمدة 50 عامًا</h3><p>بالنسبة لوحدات التصريف الأساسية المصنوعة من الفولاذ المقاوم للصدأ البحري من الدرجة 316/316L، نوفر ضمانًا ضد التآكل والسلامة الهيكلية يصل إلى 50 عامًا في ظل الاستخدام العادي والصيانة المناسبة.</p><h3>2. ضمان الأداء وتحمل الأحمال</h3><p>جميع الشبكات والأغطية الصادرة من ASTREVA تخضع لاختبارات أحمال مستقلة من طرف ثالث، وتتوافق مع مستويات تحمل الأحمال الرئيسية المعتمدة عالميًا.</p>", "hero": {"title": "سياسة الضمان وخدمة ما بعد البيع", "description": "سياسة الضمان وخدمة ما بعد البيع لأنظمة تصريف المياه من الفولاذ المقاوم للصدأ من ASTREVA.", "backgroundVideo": ""}, "slug": "warranty", "title": "سياسة الضمان وخدمة ما بعد البيع", "sections": {"icon": "盾"}}, {"seo": {"title": "دليل التركيب | ASTREVA", "description": "اطّلع على خطوات تركيب نظام تصريف المياه بقفل Click من ASTREVA."}, "body": "<h3>الخطوة ١: تجهيز الخندق الأساسي</h3><p>وفقًا لمتطلبات مخططات المشروع، يتم حفر خندق بعرض وعمق كافيين، ثم فرش طبقة أساس خرسانية.</p><h3>الخطوة ٢: تجميع الوحدات وقفلها</h3><p>قم بمحاذاة وحدتين متجاورتين من قنوات تصريف المياه من الفولاذ المقاوم للصدأ من ASTREVA، وحقق اتصالًا محكمًا مانعًا للتسرب من خلال آلية قفل Click الحاصلة على براءة اختراع.</p><h3>الخطوة ٣: ضبط الارتفاع والتثبيت</h3><p>استخدم مسامير أقواس ضبط الارتفاع المدمجة على جانبي القناة لضبط نظام التصريف بدقة على مستوى الارتفاع المطلوب.</p>", "hero": {"title": "دليل تركيب نظام قفل Click", "description": "اطّلع على خطوات تركيب نظام تصريف المياه بقفل Click من ASTREVA.", "backgroundVideo": ""}, "slug": "install", "title": "دليل تركيب نظام قفل Click", "sections": {"icon": "工"}}, {"seo": {"title": "سياسة الخصوصية | ASTREVA", "description": "سياسة الخصوصية للموقع الرسمي لـ ASTREVA."}, "body": "<p>تاريخ السريان: 1 يناير 2026</p><p>تولي ASTREVA أهمية كبيرة لخصوصيتكم. توضح سياسة الخصوصية هذه كيفية جمع معلوماتكم الشخصية واستخدامها والإفصاح عنها وحمايتها عند زيارتكم لموقعنا الإلكتروني أو استخدامكم لخدماتنا.</p><h3>جمع المعلومات</h3><p>عند تقديمكم استفسارًا أو طلب عرض أسعار أو الاشتراك في النشرة الإخبارية عبر نماذجنا الإلكترونية، قد نقوم بجمع اسمكم ورقم هاتفكم وعنوان بريدكم الإلكتروني ومتطلبات مشروعكم.</p>", "hero": {"title": "سياسة الخصوصية", "description": "سياسة الخصوصية للموقع الرسمي لـ ASTREVA.", "backgroundVideo": ""}, "slug": "privacy", "title": "سياسة الخصوصية"}, {"seo": {"title": "اتفاقية خدمة المستخدم | ASTREVA", "description": "اتفاقية خدمة المستخدم للموقع الرسمي لـ ASTREVA."}, "body": "<p>نشكركم على زيارة الموقع الرسمي لشركة ASTREVA. قبل استخدام هذا الموقع، يرجى قراءة الشروط والأحكام التالية بعناية.</p><h3>محتوى الموقع والملكية الفكرية</h3><p>جميع المحتويات على هذا الموقع محمية بموجب قوانين حقوق النشر، ولا يحق لأي شخص نسخ هذه المواد أو توزيعها أو تعديلها لأغراض تجارية دون الحصول على إذن كتابي.</p><h3>إخلاء المسؤولية عن معلومات المنتجات</h3><p>تُعتبر المعايير الهندسية التفصيلية وفقًا للخطة الرسمية النهائية والاتفاقية الفنية التي يصدرها مهندسونا لكم هي المرجع المعتمد.</p>", "hero": {"title": "اتفاقية خدمة المستخدم", "description": "اتفاقية خدمة المستخدم للموقع الرسمي لشركة ASTREVA.", "backgroundVideo": ""}, "slug": "agreement", "title": "اتفاقية خدمة المستخدم"}, {"seo": {"title": "الحلول | ASTREVA", "description": "استعرض حلول أنظمة الصرف من ASTREVA للبلديات والمناطق التجارية والصناعية والمناظر الطبيعية والمدن الإسفنجية وغيرها."}, "body": "", "hero": {"title": "حلول صرف منهجية\\nمصممة للسيناريوهات الواقعية", "eyebrow": "Solutions", "subtitle": "نقدم حلولًا متكاملة من اختيار المنتجات إلى التركيب الفعلي، تغطي سيناريوهات البلديات والمناطق التجارية والصناعية والمناظر الطبيعية وغيرها.", "description": "من حسابات النماذج الهيدروليكية وتقييم فئات التحمل إلى مطابقة الخصائص الكيميائية للمواد، لا تقدم ASTREVA مجرد قنوات تصريف فحسب، بل توفر يقينًا هندسيًا للتعامل مع البيئات القاسية.", "backgroundImage": "", "backgroundVideo": ""}, "slug": "solutions", "title": "الحلول", "sections": {"ctaHref": "/support/", "ctaIcon": "→", "ctaLabel": "عرض الدليل الفني التفصيلي", "bulletIcon": "✓", "detailNote": "للاستفسار عن المواصفات التفصيلية وشروط التركيب، يرجى التواصل مع فريق ASTREVA الفني.", "introTitle": "اختر الحل حسب سيناريو التطبيق", "adviceTitle": "هل تحتاج إلى استشارة احترافية لاختيار المنتج المناسب؟", "featureIcon": "✓", "systemCards": [{"step": "الخطوة 01. التصريف عبر الفتحات الضيقة", "title": "فتحة بعرض 10-20 مم فقط، تختفي بسلاسة بين فواصل الأحجار."}, {"step": "الخطوة 02. جسم القناة عالي المتانة", "title": "القاع الأملس على شكل U يوفر سرعة تنظيف ذاتي فائقة، مما يقلل من الترسبات."}, {"step": "الخطوة 03. صيانة مخفية", "title": "غطاء فتحة الصيانة الحاصل على براءة اختراع يمكن ملؤه بأحجار بنفس اللون، لتحقيق توحيد بصري بنسبة 100%."}], "sideNavTitle": "التنقل بين الحلول", "videoPlayIcon": "▶", "introDescription": "تحليل نظام الصرف بناءً على الظروف الهندسية الفعلية، مع استكمال الاختيار الشامل من حيث التحمل والمواد والميل والصيانة والمظهر البصري.", "solutionSections": [{"id": "sol-sec-1", "image": "", "title": "الطرق البلدية والساحات العامة الحضرية", "number": "01", "bullets": ["يلبي أعلى متطلبات التحمل من الفئة F900 وفقًا لمعيار EN1433", "تصميم مقاوم للهبوط يمنع تكسّر الوصلات بين أسطح الطرق", "حسابات نموذج تصريف فائقة السرعة للتعامل مع العواصف المطرية التي تحدث مرة كل 50 عامًا"], "ctaHref": "", "ctaLabel": "", "navLabel": "تصريف مياه الطرق البلدية", "videoUrl": "", "detailNote": "للاستفسار عن المواصفات التفصيلية وشروط التركيب، يُرجى التواصل مع الفريق الفني في شينغدو.", "focusTitle": "الحل الجوهري: الاستقرار الهيكلي", "videoImage": "", "description": "في الطرق الرئيسية الحضرية ومحاور النقل والساحات العامة الكبيرة، يتمثّل التحدي الأبرز لأنظمة التصريف في الأحمال عالية التردد والأمطار الغزيرة المفاجئة. النظام المعياري من فئة F900 من شينغدو مصمَّم خصيصًا لهذا الغرض.", "videoCaption": "فيديو التركيب وقدرة التحمّل: عرض توضيحي لتركيب نظام الفولاذ المقاوم للصدأ F900 في المحاور الحضرية", "focusDescription": "يعتمد على قنوات مسبقة الصنع من الفولاذ المقاوم للصدأ بتصميم متكامل، بديلًا عن القنوات الخرسانية المصبوبة في الموقع. خصائصه الفيزيائية تضمن عدم حدوث تقشّر خرساني أو اتساع في الفواصل تحت الأحمال الثقيلة. نظام القفل Click يضمن الاتساق في التركيبات طويلة المدى."}, {"id": "sol-sec-2", "title": "المجمعات التجارية والفنادق من فئة الخمس نجوم", "number": "02", "bullets": ["تصريف المياه عبر فتحات ضيقة بعرض 10-20 ملم فقط، مخفية بين فواصل الأحجار", "قاع أملس على شكل حرف U يوفر سرعة تدفق عالية للتنظيف الذاتي", "فتحة صيانة مخفية قابلة للتكسية بنفس لون الحجر لتحقيق التجانس البصري"], "ctaHref": "/support/", "ctaLabel": "عرض الدليل الفني التفصيلي", "navLabel": "المجمعات التجارية", "detailNote": "للتأكد من المواصفات التفصيلية وشروط التركيب، يرجى التواصل مع فريق ASTREVA الفني.", "focusTitle": "التوازن الأمثل بين الجمال والأداء", "description": "لا تتطلب البيئات التجارية أداءً وظيفيًا متميزًا فحسب، بل تتطلب أيضًا اختفاءً بصريًا تامًا. يجب أن تندمج أنظمة التصريف بسلاسة مع أرضيات الأحجار الفاخرة، مع ضمان السلامة وسهولة الصيانة في ظل حركة المشاة الكثيفة.", "focusDescription": "يمكن تطبيق نظام التصريف المخفي من ASTREVA في المشاريع التجارية والفندقية الفاخرة. نوفر مخططات BIM متكاملة لضمان محاذاة وحدات التبليط خلال مرحلة التصميم."}, {"id": "sol-sec-3", "image": "", "title": "تصريف المصانع وغرف النظافة", "number": "03", "bullets": ["مصنوع من الفولاذ المقاوم للصدأ 316L، مقاوم لبيئات التنظيف بالأحماض والقلويات القوية", "تصميم بزوايا مستديرة متوافق مع متطلبات HACCP", "شبكات عالية المتانة تتناسب مع المناورات المتكررة للرافعات الشوكية الثقيلة"], "ctaHref": "", "ctaLabel": "", "navLabel": "الصناعي وغرف النظافة", "detailNote": "للاستفسار عن المواصفات التفصيلية وشروط التركيب، يُرجى التواصل مع فريق ASTREVA التقني.", "focusTitle": "مقاومة التآكل وانعدام الزوايا الصحية الميتة", "description": "في ورش إنتاج الأغذية والأدوية، يُعدّ نظام الصرف عنصرًا محوريًا في مكافحة التلوث. نظام القنوات المفتوحة الصناعي من الفولاذ المقاوم للصدأ بالكامل من ASTREVA يعتمد معالجة التلميع المرآتي ويدعم التنظيف في الموقع (CIP).", "focusDescription": "مادة الفولاذ المقاوم للصدأ 316L تتكيّف مع بيئات التنظيف بالأحماض والقلويات المركّزة، وقاع القناة ذو الزوايا المستديرة يقلّل من تراكم الأوساخ، مما يجعله مناسبًا للمصانع النظيفة ومعالجة الأغذية ومناطق الغسيل عالي التردد."}, {"id": "sol-sec-4", "image": "", "title": "تخصيص المناظر الطبيعية الراقية والأرضيات غير المنتظمة", "number": "04", "bullets": ["يدعم التخصيص بالمنحنيات والخطوط المتعرّجة والمقاسات غير القياسية", "يتناسق مع الأسطح الحجرية والطوبية والمعدنية", "نقاط فحص مخفية تجمع بين سهولة الصيانة والجمالية"], "ctaHref": "", "ctaLabel": "", "navLabel": "تخصيص المناظر الطبيعية الراقية", "detailNote": "للاطلاع على المواصفات التفصيلية وشروط التركيب، يُرجى التواصل مع فريق ASTREVA الفني.", "focusTitle": "دمج أنظمة الصرف في لغة الرصف", "description": "سواء في الرصف المنحني أو النوافير الساحية أو الأحياء التجارية أو أفنية المساكن الفاخرة، يجب أن تكون أنظمة الصرف مخفية ومتوافقة مع الحدود المعقدة في آنٍ واحد. تدعم ASTREVA التخصيص على مستوى الأقواس والأشكال غير المنتظمة والعقد.", "focusDescription": "من خلال تخصيص نصف قطر الانحناء وعرض الفواصل وعقد الصيانة، يمكن أن تصبح قنوات الصرف جزءًا من فواصل الرصف، بدلاً من أن تكون عناصر نشازًا تُخلّ بوحدة المنظر العام."}, {"id": "sol-sec-5", "image": "", "title": "المدن الإسفنجية والاستخدام البيئي لمياه الأمطار", "number": "05", "bullets": ["متوافق مع عقد المدن الإسفنجية والرصف البيئي", "يدعم جمع مياه الأمطار والفحص والصيانة", "يمكن ربطه بأنظمة صرف المناظر الطبيعية وشبكات الأنابيب البلدية"], "ctaHref": "", "ctaLabel": "", "navLabel": "المدن الإسفنجية / الاستدامة البيئية", "detailNote": "للاطلاع على المواصفات التفصيلية وشروط التركيب، يرجى التواصل مع فريق أستريفا التقني.", "focusTitle": "من التصريف السريع إلى إدارة مياه الأمطار", "description": "تُدمج أستريفا حلول التصريف والتخزين المؤقت ونقاط الفحص والصيانة في نظام مستدام لإدارة مياه الأمطار، لتلبية احتياجات الحدائق والمساحات الخضراء والتجديد الحضري والأحياء البيئية.", "focusDescription": "يمكن الجمع بين المواد البيئية المنفذة للمياه، ومجمعات مياه الأمطار، ونقاط آبار الفحص، لمساعدة المشاريع على تحقيق التوازن بين مواجهة العواصف المطرية والصيانة الدورية والحصول على شهادات الاستدامة."}], "advicePrimaryHref": "/support/", "architectureTitle": "هيكل نظام الشقوق المخفية", "advicePrimaryLabel": "استشر خبراء الحلول", "adviceSecondaryHref": "/products/", "adviceSecondaryLabel": "تحميل الكتالوج الكامل"}}], "productCenter": {"seo": {"title": "مركز المنتجات | ASTREVA", "description": "تصفّح أنظمة الصرف المعيارية من ASTREVA، والشبكات، وأغطية المناهل، ومنتجات صرف المناظر الطبيعية حسب سيناريو التطبيق."}, "hero": {"title": "مركز المنتجات", "description": "استكشف تطبيقات أنظمتنا في المجالات الأساسية، واختر قطاع أعمالك للاطلاع على الحلول المخصصة.", "backgroundImage": "", "backgroundVideo": ""}, "intro": {"title": "اختر سيناريو التطبيق وقطاع الأعمال", "description": "سنوفر لك الحل الأمثل الذي يتناسب بدقة مع احتياجاتك", "categoryCtaLabel": "عرض المنتجات ذات الصلة"}, "catalog": {"eyebrow": "Product Center", "description": "ابحث بسرعة عن منتجات الصرف الاحترافية من الفولاذ المقاوم للصدأ ومكونات الأنظمة حسب نوع المنتج.", "viewAllLabel": "عرض الكل", "categoriesTitle": "فئات المنتجات", "categoriesEyebrow": "Product Categories", "categoriesAriaLabel": "فئات المنتجات", "emptyCategoryMessage": "سلسلة منتجات هذه الفئة قيد الإعداد.", "categoriesDescription": "اختر نظام المنتجات من القائمة اليسرى لعرض المنتجات والمكونات المقابلة."}, "detailPage": {"badgeIcon": "✓", "badgeLabel": "جودة صناعية فائقة", "specsTitle": "المواصفات والمعطيات التقنية", "videoTitle": "فيديو المنتج", "featureIcon": "✓", "galleryTitle": "معرض صور المنتجات", "descriptionIcon": "التصنيع", "quoteButtonIcon": "✉", "descriptionTitle": "وصف المنتج", "quoteButtonLabel": "الحصول على عرض سعر المشروع", "specsDescription": "أبعاد معيارية نمطية، مع دعم التخصيص الكامل وفقاً لمتطلبات المشروع.", "specsPrimaryIcon": "الطبقات", "specsPrimaryTitle": "المواد والحرفية", "downloadButtonIcon": "↓", "breadcrumbSeparator": "›"}, "categoryPage": {"backIcon": "←", "backLabel": "العودة لإعادة اختيار قطاع الأعمال", "titleTemplate": "{category} - حلول منتجات مخصصة", "categoryCtaIcon": "→", "productHoverLabel": "عرض التفاصيل"}}}	1	ready		2026-08-29 05:11:51.254+00	2026-08-29 05:24:19.388+00	2026-08-28 03:53:02.701262+00	2026-08-29 05:24:19.389693+00
en	{"faqs": [{"id": "faq_custom", "answer": "Full support is available. In addition to standardized modules, our engineering team can customize special-shaped, curved, and special-width stainless steel drainage systems based on your site terrain, hydraulic flow, and curve requirements.", "enabled": true, "question": "Do your drainage systems support customization?", "sortOrder": 10}, {"id": "faq_click", "answer": "Traditional resin concrete or masonry drainage channels are very heavy and require cumbersome plastering or on-site welding. Our Click system weighs only one-fifth of traditional systems and features a built-in mechanical interlocking waterproof buckle, completely eliminating welding and curing wait times—install and use immediately.", "enabled": true, "question": "Why is the Click system installed so much faster than traditional drainage channels?", "sortOrder": 20}, {"id": "faq_load", "answer": "Yes. Our specific heavy-duty models comply with the F900 class of the EU EN1433 standard and can withstand extreme loads from airport runways and heavy-duty logistics warehousing.", "enabled": true, "question": "Can the products withstand being run over by heavy trucks?", "sortOrder": 30}, {"id": "faq_delivery", "answer": "For standard models and lengths, we maintain ample inventory and can ship within 3-5 business days. For highly customized engineered systems, the production lead time is usually between 2-4 weeks.", "enabled": true, "question": "What is the typical order lead time?", "sortOrder": 40}], "home": {"cta": {"title": "Planning your next project?", "description": "If you need an efficient, attractive, and durable drainage system, contact our team of engineering experts today for a free quote.", "primaryHref": "/support/", "primaryLabel": "Contact Us", "secondaryHref": "/products/", "secondaryLabel": "Download Product Catalog", "backgroundImage": ""}, "seo": {"title": "ASTREVA | Modular Stainless Steel Drainage Systems", "description": "Innovative drainage solutions for architectural and municipal applications, focused on efficient, attractive, and durable modular stainless steel drainage systems."}, "hero": {"title": "ASTREVA", "eyebrow": "The fastest drainage system. Absolutely.", "subtitle": "Innovative Solutions in Building and Municipal Drainage", "videoUrl": "https://youtube.com/shorts/XhHzoY3kG54?feature=share", "trademark": "TM", "primaryCta": "Explore Products", "videoTitle": "Xingdu ASTREVA Promotional Video", "primaryHref": "/products/", "secondaryCta": "Play Video", "backgroundImage": "", "backgroundVideo": "", "videoCloseLabel": "Close Video", "videoPreviewLabel": "Promotional Video Player (Preview)", "videoOpenExternalLabel": "Unable to play? Open on YouTube"}, "partners": ["LANDLEASE", "LA SIMON BUILDERS", "MA CIVIL DESIGN", "MULTIPLEX", "BESIX Watpac"], "advantages": [{"icon": "▶", "title": "Ultra-Fast Installation", "description": "Patented Click lock system for one-second assembly."}, {"icon": "✓", "title": "Extreme Durability", "description": "Backed by a service life warranty of up to 50 years."}, {"icon": "工", "title": "Superior Load Capacity", "description": "Class G load-bearing tested, suitable for heavy-duty zones."}, {"icon": "滴", "title": "Eco-Friendly Materials", "description": "100% recyclable stainless steel, supporting LEED certification."}], "partnerLabel": "Our Partners:", "productIntro": {"image": "", "title": "What are our products?", "bullets": ["100% modular design, reducing construction time by 80%", "Lightweight materials, lowering transportation and labor costs", "Seamless joints, completely eliminating leakage", "Aesthetic architectural-grade appearance, suitable for any floor surface"], "ctaHref": "/products/", "ctaLabel": "View technical specifications", "bulletIcon": "✓", "description": "ASTREVA is committed to developing and producing the world's fastest and most reliable modular drainage systems. We have abandoned traditional bulky drainage channels in favor of high-strength stainless steel, creating a click-and-go connection system."}, "testimonials": [], "advantagesIntro": {"title": "Experience product advantages", "description": "Why do the world's top contractors and architects choose 星渡ASTREVA?"}, "featuredProducts": {"title": "Featured Products", "linkIcon": "→", "linkLabel": "Learn More", "description": "Explore our full range of high-performance drainage products, designed for a variety of building and municipal needs."}, "testimonialsTitle": "What Our Customers Say"}, "site": {"chat": {"title": "Live Chat", "ariaLabel": "Live Chat", "errorTitle": "Chat window failed to load", "loadingText": "Connecting to online support...", "errorDescription": "Please confirm that the ServiceBridge client service is running", "initialUnreadCount": 1}, "email": "info@astreva.com", "phone": "", "cookie": {"text": "This website uses cookies to ensure you get the best experience on our website, analyze site traffic, and support our marketing efforts.", "title": "Privacy & Cookie Usage Notice:", "suffixText": "to learn more or change your settings.", "privacyLabel": "Privacy Policy", "acceptAllLabel": "Accept All Cookies", "necessaryLabel": "Necessary Only"}, "footer": {"logoAlt": "ASTREVA Logo", "quickLinks": [{"href": "/", "label": "Home"}, {"href": "/products/", "label": "Products"}, {"href": "/about/", "label": "About Us"}, {"href": "/solutions/", "label": "Solutions"}], "description": "A leader in innovative solutions for building and municipal drainage. Providing the most efficient, modular stainless steel drainage systems.", "socialTitle": "Follow Us", "privacyLabel": "Privacy Policy", "supportLinks": [{"href": "/support/install/", "label": "Installation Guide"}, {"href": "/support/faq/", "label": "Frequently Asked Questions (FAQs)"}, {"href": "/support/warranty/", "label": "After-Sales & Warranty"}], "supportTitle": "Support", "agreementLabel": "User Agreement", "quickLinksTitle": "Quick Links", "socialEmptyText": "Social media links can be configured in the admin panel."}, "locale": "en", "logoUrl": "/assets/astreva-logo-transparent.png", "brandName": "ASTREVA", "copyright": "@ASTREVA 2026 All rights reserved.", "defaultSeo": {"image": "", "title": "ASTREVA | Building & Municipal Drainage Systems", "description": "ASTREVA provides modular stainless steel drainage channels, heavy-duty gratings, landscape drainage, and industrial drainage systems."}, "navigation": {"homeLabel": "Home", "aboutLabel": "About Us", "productMenu": {"utilityLinks": [{"href": "/products/", "icon": "file", "label": "Download Product Catalog"}, {"href": "/support/install/", "icon": "book", "label": "View Selection Guide"}, {"href": "/solutions/", "icon": "search", "label": "Browse by Application"}, {"href": "/products/", "icon": "arrow", "label": "Go to Product Center"}], "categoryLabel": "Product Categories", "mobileToggleLabel": "Expand Product Categories", "popularSeriesLabel": "Popular Series", "popularSeriesTitleTemplate": "{category} · Popular Series", "viewAllCategoryLabelTemplate": "View All {category} Products"}, "supportLabel": "Support", "productsLabel": "Products", "solutionsLabel": "Solutions", "mobileMenuLabel": "Open navigation"}, "socialIcons": {"tiktok": "TT", "twitter": "X", "youtube": "YT", "facebook": "F", "telegram": "TG", "whatsapp": "WA", "instagram": "IG"}, "socialLinks": {}, "brandTagline": "A Grate Innovation", "localization": {"arabicLabel": "العربية", "chineseLabel": "Chinese", "englishLabel": "English", "languageLabel": "Language", "switchingText": "Switching...", "switchAriaLabel": "Switch website language", "unavailableText": "Translation unavailable"}, "serviceBridgeUrl": "http://127.0.0.1:5173"}, "support": {"seo": {"title": "Service & Support | 星渡ASTREVA", "description": "Get product quotes, technical support, installation guides, and after-sales warranty services for 星渡ASTREVA."}, "hero": {"title": "Service & Support", "description": "We provide comprehensive technical support, installation guidance, and after-sales service to ensure your project runs flawlessly.", "backgroundImage": "", "backgroundVideo": ""}, "contact": {"form": {"nameLabel": "Your Name", "emailLabel": "Email Address", "phoneLabel": "Phone Number", "submitLabel": "Submit", "companyLabel": "Company or Project Name", "errorMessage": "Submission failed. Please contact us by phone or email.", "messageLabel": "Message", "optionalLabel": "Optional", "successMessage": "Thank you for your submission. We will contact you shortly.", "namePlaceholder": "Enter your name", "submittingLabel": "Submitting...", "emailPlaceholder": "Your email", "phonePlaceholder": "Your phone number", "companyPlaceholder": "Enter your company or project name", "messagePlaceholder": "Please describe your project requirements or technical questions...", "missingEndpointMessage": "The backend endpoint has not been configured yet. Please try again later."}, "title": "Contact Us", "emailIcon": "✉", "phoneIcon": "☎", "emailLabel": "Business Email", "phoneLabel": "Sales Inquiry", "description": "Whether you need a quotation or technical consultation, our team of experts is ready to assist you."}, "services": [{"cta": "View Warranty Policy", "href": "/support/warranty/", "icon": "盾", "title": "After-sales & Warranty", "description": "Learn about our 50-year extended service life warranty policy, along with professional on-site maintenance and after-sales inspection services."}, {"cta": "View installation manual", "href": "/support/install/", "icon": "工", "title": "Installation Guide", "description": "View detailed video tutorials and step-by-step guides to learn advanced installation techniques and drawing specifications for the Click locking system."}, {"cta": "Browse FAQ", "href": "/support/faq/", "icon": "?", "title": "Frequently Asked Questions (FAQ)", "description": "Quickly find answers to frequently asked questions about product selection, load-bearing standards, shipping lead times, and customization requirements."}]}, "products": [{"id": "prod_heavy_modular_stainless", "seo": {"title": "Heavy-Duty Modular Stainless Steel Drainage Channel | Xingdu ASTREVA", "description": "Heavy-duty modular stainless steel drainage channels for municipal and public works."}, "body": "The system not only delivers exceptional corrosion resistance and hydraulic performance, but also provides a reliable service life of up to 50 years in the most demanding environments.", "name": "Heavy-Duty Modular Stainless Steel Drainage Channel", "slug": "heavy-modular-stainless-drain", "summary": "Precision-manufactured from premium 316/316L stainless steel, combined with the patented Click lock technology.", "features": ["Patented seamless joining technology, 100% leak-proof", "Compliant with EN1433 international load-bearing standards", "One-piece molded structure effectively prevents debris from clogging", "Anti-slip surface treatment compliant with ADA building safety regulations"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": true, "categorySlug": "municipal-public-works", "galleryImages": [], "specifications": [{"label": "Body Material", "value": "Stainless steel grade AISI 304 or AISI 316L"}, {"label": "Internal Width", "value": "100mm / 150mm / 200mm / 300mm"}, {"label": "Load Class", "value": "A15 - F900"}]}, {"id": "prod_municipal_grate", "seo": {"title": "High-Load Custom Municipal Grating | ASTREVA", "description": "Custom solutions for high-load municipal gratings and drainage covers."}, "body": "Suitable for high-frequency traffic and long-term exposure environments, with support for engineering customization.", "name": "High-Load Custom Municipal Grating", "slug": "high-load-custom-municipal-grate", "summary": "High-load, easy-maintenance grating systems for municipal roads and public spaces.", "features": ["High-load structure", "Quick access for maintenance", "Corrosion-resistant surface treatment"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": true, "categorySlug": "municipal-public-works", "galleryImages": [], "specifications": [{"label": "Load class", "value": "D400 - F900"}]}, {"id": "prod_slot_drain", "seo": {"title": "Invisible Slot Drainage System | ASTREVA", "description": "Invisible slot drainage system for commercial and high-end residential use."}, "body": "Narrow slot intake and modular channel body balance aesthetics with efficiency.", "name": "Invisible Slot Linear Resin Drainage System", "slug": "invisible-slot-resin-drainage-system", "summary": "A low-visual-impact drainage system suitable for commercial plazas, high-end residential projects, and landscape paving.", "features": ["Invisible slot appearance", "Compatible with stone and floor tiles", "Stable drainage performance"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": true, "categorySlug": "commercial-premium-residential", "galleryImages": [], "specifications": [{"label": "Slot width", "value": "8mm / 12mm / 20mm"}]}, {"id": "prod_rain_collector", "seo": {"title": "Landscape-Grade Rainwater Collector | ASTREVA", "description": "A rainwater collection and drainage node designed for landscape spaces."}, "body": "Seamlessly integrate stormwater management with landscape design.", "name": "Landscape-Grade Rainwater Collector", "slug": "landscape-rainwater-collector", "summary": "An architectural-grade node product for organizing and collecting landscape rainwater.", "features": ["Easy to clean", "Customizable surface finish", "Coordinates with paving"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "commercial-premium-residential", "galleryImages": [], "specifications": [{"label": "Surface finish", "value": "Stainless steel / stone insert"}]}, {"id": "prod_industrial_channel", "seo": {"title": "Corrosion-Resistant Industrial-Grade Stainless Steel Channel Drain | ASTREVA", "description": "Industrial-grade corrosion-resistant stainless steel channel drain system."}, "body": "Suitable for food processing, chemical, logistics, and manufacturing environments.", "name": "Corrosion-Resistant Industrial-Grade Stainless Steel Channel Drain", "slug": "anti-corrosion-industrial-stainless-channel", "summary": "Designed for industrial corrosive environments and high-intensity washdown scenarios.", "features": ["316L corrosion resistance", "Sanitary-grade welding", "Withstands high-pressure rinsing"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": false, "categorySlug": "industrial-warehouse", "galleryImages": [], "specifications": [{"label": "Material", "value": "316L stainless steel"}]}, {"id": "prod_industrial_cover", "seo": {"title": "Industrial-Grade Load-Bearing Manhole Cover | ASTREVA", "description": "Heavy-duty manhole covers for industrial and warehouse facilities."}, "body": "Customized according to site load requirements and maintenance frequency.", "name": "Industrial-Grade Load-Bearing Manhole Cover", "slug": "industrial-heavy-duty-manhole-cover", "summary": "Load-bearing manhole covers for warehouses, industrial plants, and heavy vehicle areas.", "features": ["High load capacity", "Anti-slip surface", "Easy-maintenance opening"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "industrial-warehouse", "galleryImages": [], "specifications": [{"label": "Load capacity", "value": "D400 - F900"}]}, {"id": "prod_curve_drain", "seo": {"title": "Curved Custom Floor Drainage System | ASTREVA", "description": "Custom solutions for curved and irregular floor drainage."}, "body": "For plazas, parks, courtyards, and special architectural nodes.", "name": "Curved Custom Floor Drainage System", "slug": "custom-curved-floor-drainage-system", "summary": "Supports custom drainage for curved, irregular, and complex floor boundaries.", "features": ["Custom Curves", "Ideal for Landscape Spaces", "Precise Modular Assembly"], "videoUrl": "", "downloads": [], "sortOrder": 10, "coverImage": "", "isFeatured": false, "categorySlug": "landscape-special-drainage", "galleryImages": [], "specifications": [{"label": "Custom Radius", "value": "Fabricated to Project Drawings"}]}, {"id": "prod_permeable_well", "seo": {"title": "Eco-Permeable Materials and Inspection Chambers | 星渡ASTREVA", "description": "Eco-permeable materials and inspection chamber drainage nodes."}, "body": "Supports integrated design for urban stormwater retention, infiltration, and discharge.", "name": "Ecological Permeable Materials and Inspection Chamber", "slug": "ecological-permeable-materials-and-inspection-well", "summary": "A stormwater management node combining ecological permeable paving and maintainable inspection chamber.", "features": ["Ecological permeability", "Easy maintenance", "Suitable for sponge city"], "videoUrl": "", "downloads": [], "sortOrder": 20, "coverImage": "", "isFeatured": false, "categorySlug": "landscape-special-drainage", "galleryImages": [], "specifications": [{"label": "Application", "value": "Sponge city / Landscape renovation"}]}], "categories": [{"id": "cat_municipal", "seo": {"title": "Municipal and Public Works Drainage Systems | ASTREVA", "description": "Modular stainless steel drainage solutions for municipal roads, public plazas, and large-scale infrastructure."}, "name": "Municipal & Public Works", "slug": "municipal-public-works", "heroVideo": "", "sortOrder": 10, "coverImage": "", "description": "Heavy-duty drainage systems for roads, plazas, and public facilities."}, {"id": "cat_commercial", "seo": {"title": "Commercial & High-End Residential Drainage Systems | ASTREVA", "description": "Invisible drainage systems for commercial complexes, high-end residences, and landscape spaces."}, "name": "Commercial & High-End Residential", "slug": "commercial-premium-residential", "heroVideo": "", "sortOrder": 20, "coverImage": "", "description": "High-end solutions that balance architectural aesthetics, concealed drainage, and long-term durability."}, {"id": "cat_industrial", "seo": {"title": "Industrial & Warehouse Drainage Systems | ASTREVA", "description": "Stainless steel drainage products for industrial plants, warehousing logistics, and heavy-duty areas."}, "name": "Industrial & Warehouse Facilities", "slug": "industrial-warehouse", "heroVideo": "", "sortOrder": 30, "coverImage": "", "description": "Industrial drainage systems designed for heavy load, corrosive, and high-traffic environments."}, {"id": "cat_landscape", "seo": {"title": "Landscape & Specialty Drainage Systems | ASTREVA", "description": "Custom drainage solutions for landscapes, parks, courtyards, and irregular floor surfaces."}, "name": "Landscape & Specialty Drainage", "slug": "landscape-special-drainage", "heroVideo": "", "sortOrder": 40, "coverImage": "", "description": "Customized drainage supporting curved, irregular, eco-permeable, and special node designs."}], "staticPages": [{"seo": {"title": "About Us | ASTREVA", "description": "Learn about the brand, technical philosophy, and drainage system innovations of ASTREVA."}, "body": "<p>ASTREVA is a globally leading R&D and manufacturing company for architectural and municipal drainage systems. We have moved away from traditional cast iron and concrete channels, pioneering the <strong>100% modular stainless steel Click lock system</strong>.</p><p>Our R&D center and manufacturing base are equipped with the world's most advanced automated production lines, ensuring every inch of stainless steel achieves aerospace-grade precision.</p><h2>We don't just manufacture products—we are redefining engineering standards.</h2><p>From invisible seams in commercial plazas to heavy-duty grates on municipal load-bearing roads, ASTREVA has earned the trust of top architects and general contractors worldwide through exceptional corrosion resistance, a service life exceeding 50 years, and extremely fast installation.</p>", "hero": {"title": "The Force Driving Global Drainage Innovation", "eyebrow": "About Us", "description": "Since its founding, ASTREVA has been dedicated to reshaping the lifelines of the built environment with cutting-edge technology and top-tier manufacturing processes.", "backgroundImage": "", "backgroundVideo": ""}, "slug": "about", "title": "About ASTREVA", "sections": {"introIcon": "Drop", "partnersTitle": "Globally Trusted Partners"}}, {"seo": {"title": "FAQ | ASTREVA", "description": "View frequently asked questions about product selection, customization, load ratings, delivery, and installation for ASTREVA drainage systems."}, "body": "", "hero": {"title": "Frequently Asked Questions (FAQs)", "description": "View frequently asked questions about product selection, customization, load ratings, delivery, and installation for ASTREVA drainage systems.", "backgroundVideo": ""}, "slug": "faq", "title": "Frequently Asked Questions (FAQs)", "sections": {"intro": ""}}, {"seo": {"title": "After-Sales & Warranty Policy | ASTREVA", "description": "ASTREVA stainless steel drainage system warranty policy and after-sales service."}, "body": "<p>At ASTREVA, we are confident in the exceptional quality of our products. Our stainless steel drainage systems are engineered to withstand the most demanding environments.</p><h3>1. 50-Year Extended Material Warranty</h3><p>For core drainage modules manufactured from 316/316L marine-grade stainless steel, we offer up to a 50-year warranty against corrosion and structural integrity under normal use and proper maintenance.</p><h3>2. Performance & Load Rating Guarantee</h3><p>All grates and covers shipped by ASTREVA undergo independent third-party load testing and comply with major global load rating standards.</p>", "hero": {"title": "After-Sales & Warranty Policy", "description": "Warranty policy and after-sales service for ASTREVA stainless steel drainage systems.", "backgroundVideo": ""}, "slug": "warranty", "title": "After-Sales & Warranty Policy", "sections": {"icon": "盾"}}, {"seo": {"title": "Installation Guide | ASTREVA", "description": "View the installation steps for the ASTREVA Click locking drainage system."}, "body": "<h3>Step 1 Preparing the Foundation Trench</h3><p>Excavate a trench of sufficient width and depth according to the project drawings, and lay a concrete bedding layer.</p><h3>Step 2 Module Connection & Locking</h3><p>Align two adjacent ASTREVA stainless steel channel modules and achieve a seamless waterproof connection through the patented Click locking mechanism.</p><h3>Step 3 Height Adjustment & Fixing</h3><p>Use the height adjustment bracket bolts on both sides of the channel body to precisely level the drainage system to the required elevation.</p>", "hero": {"title": "Click Locking System Installation Guide", "description": "View the installation steps for the ASTREVA Click locking drainage system.", "backgroundVideo": ""}, "slug": "install", "title": "Click Locking System Installation Guide", "sections": {"icon": "工"}}, {"seo": {"title": "Privacy Policy | ASTREVA", "description": "Privacy policy for the official ASTREVA website."}, "body": "<p>Effective Date: January 1, 2026</p><p>ASTREVA attaches great importance to your privacy. This Privacy Policy explains how we collect, use, disclose, and protect your personal information when you visit our website or use our services.</p><h3>Information Collection</h3><p>When you submit an inquiry, request a quote, or subscribe to our newsletter through our online forms, we may collect your name, phone number, email address, and project requirements.</p>", "hero": {"title": "Privacy Policy", "description": "Privacy policy for the official ASTREVA website.", "backgroundVideo": ""}, "slug": "privacy", "title": "Privacy Policy"}, {"seo": {"title": "Terms of Service | ASTREVA", "description": "Terms of Service for the official ASTREVA website."}, "body": "<p>Thank you for visiting the official ASTREVA website. Please read the following terms and conditions carefully before using this website.</p><h3>Website Content and Intellectual Property</h3><p>All content on this website is protected by copyright law. No one may reproduce, distribute, or modify these materials for commercial purposes without written permission.</p><h3>Product Information Disclaimer</h3><p>Specific engineering parameters shall be subject to the final official proposal and technical agreement issued by our engineers for you.</p>", "hero": {"title": "User Service Agreement", "description": "ASTREVA official website User Service Agreement.", "backgroundVideo": ""}, "slug": "agreement", "title": "User Service Agreement"}, {"seo": {"title": "Solutions | ASTREVA", "description": "Explore ASTREVA drainage system solutions for municipal, commercial, industrial, landscape, and sponge city applications."}, "body": "", "hero": {"title": "Systematic Drainage Solutions\\nfor Real-World Scenarios", "eyebrow": "Solutions", "subtitle": "Complete solutions from product selection to on-site installation for municipal, commercial, industrial, landscape, and other scenarios.", "description": "From hydraulic model calculations and load class assessments to material chemical compatibility, Xingdu ASTREVA delivers not just drainage channels but engineering certainty for extreme environments.", "backgroundImage": "", "backgroundVideo": ""}, "slug": "solutions", "title": "Solutions", "sections": {"ctaHref": "/support/", "ctaIcon": "→", "ctaLabel": "View detailed technical manual", "bulletIcon": "✓", "detailNote": "Please contact the Xingdu ASTREVA technical team to confirm specific specifications and installation conditions.", "introTitle": "Select a solution by application scenario", "adviceTitle": "Need professional selection advice?", "featureIcon": "✓", "systemCards": [{"step": "Step 01. Narrow-slot drainage", "title": "A slot of just 10–20 mm, perfectly concealed within stone joints."}, {"step": "Step 02. High-Strength Channel Body", "title": "The smooth U-shaped bottom provides ultra-high self-cleaning flow velocity to reduce sediment accumulation."}, {"step": "Step 03. Concealed Access", "title": "The patented access cover can be infilled with matching stone for 100% visual continuity."}], "sideNavTitle": "Solution Navigation", "videoPlayIcon": "▶", "introDescription": "Deconstruct the drainage system based on real-world engineering conditions to complete full selection from load capacity, material, slope, maintenance, and visual effect.", "solutionSections": [{"id": "sol-sec-1", "image": "", "title": "Municipal Roads and Urban Public Plazas", "number": "01", "bullets": ["Meets EN1433 F900 maximum load-bearing requirements", "Anti-settlement design prevents fractures at pavement joints", "High-speed drainage modeling calculations designed to handle 50-year storm events"], "ctaHref": "", "ctaLabel": "", "navLabel": "Municipal Road Drainage", "videoUrl": "", "detailNote": "Please contact the Xingdu technical team to confirm specific specifications and installation conditions.", "focusTitle": "Core Solution: Structural Stability", "videoImage": "", "description": "For urban arterial roads, transportation hubs, and large public plazas, the primary challenges facing drainage systems are high-frequency loads and sudden intense rainfall. The Xingdu F900-rated modular system is engineered specifically for these conditions.", "videoCaption": "Installation and load-bearing capacity video: Installation demonstration of the F900 load-rated stainless steel system at an urban hub", "focusDescription": "Prefabricated integrated stainless steel channel bodies replace traditional cast-in-place trenches. Their physical properties ensure no risk of concrete spalling or joint widening under heavy rolling loads. The Click locking system ensures consistency across long-distance installations."}, {"id": "sol-sec-2", "title": "Commercial Complexes and Five-Star Hotels", "number": "02", "bullets": ["Only 10-20mm narrow slot drainage, concealed within stone joints", "Smooth U-shaped bottom provides high self-cleaning flow velocity", "Concealed access points can be filled with matching stone for visual uniformity"], "ctaHref": "/support/", "ctaLabel": "View Detailed Technical Manual", "navLabel": "Commercial Complex", "detailNote": "For specific specifications and installation conditions, please contact the ASTREVA technical team for confirmation.", "focusTitle": "The Ultimate Balance of Aesthetics and Performance", "description": "The commercial environment demands not only superior functionality but also visual invisibility. Drainage systems must integrate seamlessly with premium stone paving while ensuring safety and ease of maintenance under high foot traffic.", "focusDescription": "The ASTREVA invisible drainage system is suitable for high-end commercial and hospitality projects. We provide complete BIM-compatible drawings to ensure paving module alignment is achieved during the design phase."}, {"id": "sol-sec-3", "image": "", "title": "Drainage for Industrial Plants and Cleanrooms", "number": "03", "bullets": ["316L stainless steel construction, resistant to strong acid and alkali cleaning environments", "Rounded-corner design compliant with HACCP requirements", "Heavy-duty gratings suitable for frequent turning by heavy forklifts"], "ctaHref": "", "ctaLabel": "", "navLabel": "Industrial & Cleanroom", "detailNote": "Please contact the ASTREVA technical team to confirm specific specifications and installation conditions.", "focusTitle": "Corrosion Resistance and No Sanitary Dead Corners", "description": "In food and pharmaceutical production workshops, the drainage system is central to contamination control. Xingdu's industrial-grade all-stainless steel trench drain system features mirror-polished surfaces and supports CIP (Clean-in-Place).", "focusDescription": "316L stainless steel withstands strong acid and alkali cleaning environments, and the rounded channel bottom reduces residue buildup, making it suitable for cleanrooms, food processing, and high-frequency washdown areas."}, {"id": "sol-sec-4", "image": "", "title": "Premium Landscape and Custom Shaped Flooring", "number": "04", "bullets": ["Supports customization of curves, polylines, and non-standard dimensions", "Can be coordinated with stone, brick, and metal surfaces", "Conceals maintenance access points, balancing serviceability and aesthetics"], "ctaHref": "", "ctaLabel": "", "navLabel": "Premium Landscape Customization", "detailNote": "Please contact the ASTREVA technical team to confirm specific specifications and installation conditions.", "focusTitle": "Integrating drainage systems into paving language", "description": "For curved paving, courtyard water features, commercial streetscapes, and high-end residential gardens, drainage systems need to be both concealed and adaptable to complex boundaries. ASTREVA supports curved, custom-shaped, and node-level customization.", "focusDescription": "Through customized curvature, gap width, and access points, drainage channels can become part of the paving joints rather than obtrusive elements that disrupt landscape integrity."}, {"id": "sol-sec-5", "image": "", "title": "Sponge city and ecological stormwater reuse", "number": "05", "bullets": ["Adaptable to sponge city nodes and ecological paving", "Supports rainwater collection, inspection, and maintenance", "Can be connected with landscape drainage and municipal pipe networks"], "ctaHref": "", "ctaLabel": "", "navLabel": "Sponge City / Ecology", "detailNote": "Please contact the ASTREVA technical team to confirm specific specifications and installation conditions.", "focusTitle": "From Rapid Drainage to Stormwater Management", "description": "For parks, green spaces, urban renewal, and eco-districts, ASTREVA integrates drainage, detention, inspection, and maintenance nodes into a sustainable stormwater management system.", "focusDescription": "Ecological permeable materials, rainwater harvesters, and inspection chamber nodes can be combined to help projects balance stormwater response, maintenance access, and sustainability certification."}], "advicePrimaryHref": "/support/", "architectureTitle": "Invisible Slot System Architecture", "advicePrimaryLabel": "Consult a Solution Expert", "adviceSecondaryHref": "/products/", "adviceSecondaryLabel": "Download Full Catalog"}}], "productCenter": {"seo": {"title": "Product Center | ASTREVA", "description": "Browse ASTREVA modular drainage systems, gratings, manhole covers, and landscape drainage products by application scenario."}, "hero": {"title": "Product Center", "description": "Explore our system applications across key sectors and select your business segment to view tailored solutions.", "backgroundImage": "", "backgroundVideo": ""}, "intro": {"title": "Please select an application scenario and business segment", "description": "We will precisely match you with the most suitable system solution", "categoryCtaLabel": "View related products"}, "catalog": {"eyebrow": "Product Center", "description": "Quickly find specialized stainless steel drainage products and system components by product type.", "viewAllLabel": "View All", "categoriesTitle": "Product Categories", "categoriesEyebrow": "Product Categories", "categoriesAriaLabel": "Product Categories", "emptyCategoryMessage": "Products in this category are being organized.", "categoriesDescription": "Select a product family on the left to view corresponding series products and components."}, "detailPage": {"badgeIcon": "✓", "badgeLabel": "Premium Industrial Quality", "specsTitle": "Technical Specifications & Parameters", "videoTitle": "Product Video", "featureIcon": "✓", "galleryTitle": "Product Gallery", "descriptionIcon": "Engineering", "quoteButtonIcon": "✉", "descriptionTitle": "Product Description", "quoteButtonLabel": "Request a Project Quote", "specsDescription": "Standardized modular dimensions, with deep customization available based on project requirements.", "specsPrimaryIcon": "Layer", "specsPrimaryTitle": "Materials & Craftsmanship", "downloadButtonIcon": "↓", "breadcrumbSeparator": "›"}, "categoryPage": {"backIcon": "←", "backLabel": "Back to reselect business sector", "titleTemplate": "{category} - Dedicated Product Solutions", "categoryCtaIcon": "→", "productHoverLabel": "View Details"}}}	1	ready		2026-08-29 04:54:16.947+00	2026-08-29 05:12:14.408+00	2026-08-28 03:53:02.697962+00	2026-08-29 05:12:14.408838+00
\.


--
-- Data for Name: site_fallback_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_fallback_state (id, active_version_id, updated_at) FROM stdin;
\.


--
-- Data for Name: site_fallback_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_fallback_versions (id, name, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: site_leads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_leads (id, submitted_at, updated_at, data) FROM stdin;
\.


--
-- Data for Name: site_media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_media (id, name, object_key, url, mime_type, media_type, size_bytes, storage_driver, created_at, updated_at, category, source_type, original_key, width, height, checksum_sha256, variants, metadata) FROM stdin;
\.


--
-- Data for Name: site_media_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_media_categories (name, created_at, updated_at) FROM stdin;
未分类	2026-08-28 03:51:38.151794+00	2026-08-28 03:51:38.151794+00
\.


--
-- Data for Name: site_publish_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_publish_jobs (id, status, requested_by, requested_at, started_at, finished_at, error_message, metadata) FROM stdin;
\.


--
-- Data for Name: site_runtime_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_runtime_settings (setting_key, config, encrypted_secrets, created_at, updated_at) FROM stdin;
media-runtime	{"image": {"webpQuality": 82, "keepOriginal": true, "variantWidths": "400,800,1200,1600", "maxUploadBytes": 209715200, "allowedMimeTypes": "image/jpeg,image/png,image/webp,image/gif,image/avif,video/mp4,video/webm,video/quicktime,application/pdf,application/zip,application/acad,application/dxf,image/vnd.dwg"}, "aiImage": {"baseUrl": "https://api.openai.com/v1", "allowedHosts": "api.openai.com", "defaultModel": "gpt-image-1", "downloadHosts": "api.openai.com,oaidalleapiprodscus.blob.core.windows.net", "configuredModels": "gpt-image-1,dall-e-3,dall-e-2", "requestTimeoutMs": 180000}, "storage": {"bucket": "astreva-site-media", "driver": "s3", "prefix": "site-admin", "region": "us-east-1", "endpoint": "http://minio:9000", "publicBaseUrl": "https://api.astreva.ltd/media", "forcePathStyle": true, "serverSideEncryption": ""}}	v1:sgtmOzJ2rFqLwNev:IeLqwKSbQM8Tp1PniYIOoA:8GeBK0ZWFKoVsjMGlgFzmiAajFZYd9tVvEUnTpL6Cdt3YhXJUjm6h02ro50-WUNfqVj9sI5Mim5fLxXISCy2yn2h6fBK3DcIJjg0eLgaz7yW_79LpYsbb24S_nv4AJi1DOWXjtpFh4WH3Ebiluh0YFlQvqu3aoa0o75YzCdMui5rwFoH5Ofd2tL3GZy98Q	2026-08-28 03:51:38.299042+00	2026-08-28 03:51:38.299042+00
website-translation	{"model": "gpt-5.2", "apiType": "responses", "baseUrl": "https://api.hcrx.ltd/v1", "enabled": true, "batchSize": 8, "timeoutMs": 120000, "configuredModels": ["gpt-5.2", "gpt-5.5", "gpt-5.6-luna", "gpt-5.6-sol", "gpt-5.6-terra"]}	v1:A5w_wP-BrmPxWbJo:pYCttM9sd6an3UKvahKdWQ:0IVE6DheEH14PZ5hhM5tjoIAkM_8sFKIi9uvCqpyso1KK78mmBMeZ5LG1DyKQCqR6-n0vUCDI03M2xcBRCGh98UcQCfd7d5Z_UY4PBZaQLk	2026-08-28 03:53:02.709014+00	2026-08-29 04:54:48.206132+00
\.


--
-- Data for Name: visitors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visitors (id, ip, remark, source, created_at) FROM stdin;
vis_ebec0f91287df5a5	172.19.0.1	172.19.0.1	web_mobile	2026-08-28 05:35:10.798868+00
vis_9e4c0a6bd041a62a	172.19.0.1	172.19.0.1	web_mobile	2026-08-28 05:43:59.81524+00
vis_eadb4898c358885f	172.19.0.1	172.19.0.1	web_mobile	2026-08-28 08:09:49.74105+00
vis_9ad00c05220db2c5	172.19.0.1	172.19.0.1	web_pc	2026-08-28 08:09:50.124576+00
vis_e574921ed2adcf16	172.19.0.1	172.19.0.1	web_mobile	2026-08-29 01:12:38.435902+00
vis_d982430e22cda2cb	172.19.0.1	172.19.0.1	web_mobile	2026-08-29 05:33:39.046+00
\.


--
-- Name: admin_users admin_users_account_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_account_key UNIQUE (account);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: agents agents_account_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_account_key UNIQUE (account);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: ai_settings ai_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_settings
    ADD CONSTRAINT ai_settings_pkey PRIMARY KEY (id);


--
-- Name: app_releases app_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_releases
    ADD CONSTRAINT app_releases_pkey PRIMARY KEY (id);


--
-- Name: app_releases app_releases_platform_version_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_releases
    ADD CONSTRAINT app_releases_platform_version_code_key UNIQUE (platform, version_code);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (token);


--
-- Name: business_hours business_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_hours
    ADD CONSTRAINT business_hours_pkey PRIMARY KEY (id);


--
-- Name: contact_settings contact_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_settings
    ADD CONSTRAINT contact_settings_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: keyword_rules keyword_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.keyword_rules
    ADD CONSTRAINT keyword_rules_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (server_msg_id);


--
-- Name: service_ratings service_ratings_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_ratings
    ADD CONSTRAINT service_ratings_conversation_id_key UNIQUE (conversation_id);


--
-- Name: service_ratings service_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_ratings
    ADD CONSTRAINT service_ratings_pkey PRIMARY KEY (id);


--
-- Name: site_admin_users site_admin_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_admin_users
    ADD CONSTRAINT site_admin_users_email_key UNIQUE (email);


--
-- Name: site_admin_users site_admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_admin_users
    ADD CONSTRAINT site_admin_users_pkey PRIMARY KEY (id);


--
-- Name: site_audit_events site_audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_audit_events
    ADD CONSTRAINT site_audit_events_pkey PRIMARY KEY (id);


--
-- Name: site_content site_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_content
    ADD CONSTRAINT site_content_pkey PRIMARY KEY (id);


--
-- Name: site_content_translations site_content_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_content_translations
    ADD CONSTRAINT site_content_translations_pkey PRIMARY KEY (locale);


--
-- Name: site_fallback_state site_fallback_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_fallback_state
    ADD CONSTRAINT site_fallback_state_pkey PRIMARY KEY (id);


--
-- Name: site_fallback_versions site_fallback_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_fallback_versions
    ADD CONSTRAINT site_fallback_versions_pkey PRIMARY KEY (id);


--
-- Name: site_leads site_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_leads
    ADD CONSTRAINT site_leads_pkey PRIMARY KEY (id);


--
-- Name: site_media_categories site_media_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_media_categories
    ADD CONSTRAINT site_media_categories_pkey PRIMARY KEY (name);


--
-- Name: site_media site_media_object_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_media
    ADD CONSTRAINT site_media_object_key_key UNIQUE (object_key);


--
-- Name: site_media site_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_media
    ADD CONSTRAINT site_media_pkey PRIMARY KEY (id);


--
-- Name: site_publish_jobs site_publish_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_publish_jobs
    ADD CONSTRAINT site_publish_jobs_pkey PRIMARY KEY (id);


--
-- Name: site_runtime_settings site_runtime_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_runtime_settings
    ADD CONSTRAINT site_runtime_settings_pkey PRIMARY KEY (setting_key);


--
-- Name: visitors visitors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitors
    ADD CONSTRAINT visitors_pkey PRIMARY KEY (id);


--
-- Name: idx_app_releases_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_releases_platform ON public.app_releases USING btree (platform, version_code DESC);


--
-- Name: idx_audit_events_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_actor ON public.audit_events USING btree (actor_kind, actor_id, created_at DESC);


--
-- Name: idx_audit_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_created ON public.audit_events USING btree (created_at DESC);


--
-- Name: idx_audit_events_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_resource ON public.audit_events USING btree (resource, resource_id, created_at DESC);


--
-- Name: idx_auth_sessions_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_sessions_account ON public.auth_sessions USING btree (kind, account_id);


--
-- Name: idx_auth_sessions_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_sessions_expires ON public.auth_sessions USING btree (expires_at);


--
-- Name: idx_conversations_assigned_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_assigned_agent ON public.conversations USING btree (assigned_agent_id) WHERE (assigned_agent_id IS NOT NULL);


--
-- Name: idx_conversations_status_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_status_updated ON public.conversations USING btree (status, updated_at DESC);


--
-- Name: idx_conversations_visitor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversations_visitor ON public.conversations USING btree (visitor_id);


--
-- Name: idx_keyword_rules_enabled_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_keyword_rules_enabled_priority ON public.keyword_rules USING btree (enabled, priority DESC);


--
-- Name: idx_messages_client_dedup; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_messages_client_dedup ON public.messages USING btree (conversation_id, sender_type, sender_id, client_msg_id) WHERE (client_msg_id <> ''::text);


--
-- Name: idx_messages_conversation_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_conversation_created ON public.messages USING btree (conversation_id, created_at);


--
-- Name: idx_service_ratings_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_ratings_agent ON public.service_ratings USING btree (assigned_agent_id) WHERE (assigned_agent_id IS NOT NULL);


--
-- Name: idx_service_ratings_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_ratings_created ON public.service_ratings USING btree (created_at DESC);


--
-- Name: idx_site_audit_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_audit_events_created_at ON public.site_audit_events USING btree (created_at DESC);


--
-- Name: idx_site_audit_events_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_audit_events_resource ON public.site_audit_events USING btree (resource, resource_id, created_at DESC);


--
-- Name: idx_site_content_translations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_content_translations_status ON public.site_content_translations USING btree (status, updated_at DESC);


--
-- Name: idx_site_leads_submitted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_leads_submitted_at ON public.site_leads USING btree (submitted_at DESC);


--
-- Name: idx_site_media_categories_name_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_site_media_categories_name_lower ON public.site_media_categories USING btree (lower(name));


--
-- Name: idx_site_media_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_media_category ON public.site_media USING btree (category, updated_at DESC);


--
-- Name: idx_site_media_name_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_media_name_lower ON public.site_media USING btree (lower(name));


--
-- Name: idx_site_media_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_media_type ON public.site_media USING btree (media_type, updated_at DESC);


--
-- Name: idx_site_media_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_media_updated_at ON public.site_media USING btree (updated_at DESC);


--
-- Name: idx_site_publish_jobs_requested_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_site_publish_jobs_requested_at ON public.site_publish_jobs USING btree (requested_at DESC);


--
-- Name: conversations conversations_assigned_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_assigned_agent_id_fkey FOREIGN KEY (assigned_agent_id) REFERENCES public.agents(id);


--
-- Name: conversations conversations_visitor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_visitor_id_fkey FOREIGN KEY (visitor_id) REFERENCES public.visitors(id);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: service_ratings service_ratings_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_ratings
    ADD CONSTRAINT service_ratings_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: service_ratings service_ratings_visitor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_ratings
    ADD CONSTRAINT service_ratings_visitor_id_fkey FOREIGN KEY (visitor_id) REFERENCES public.visitors(id);


--
-- Name: site_fallback_state site_fallback_state_active_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_fallback_state
    ADD CONSTRAINT site_fallback_state_active_version_id_fkey FOREIGN KEY (active_version_id) REFERENCES public.site_fallback_versions(id);


--
-- PostgreSQL database dump complete
--

\unrestrict mVsyTxDwExUfwrA3wJmmgm27SNzi74dqbIpAVWMYBm7zh6Xc9ioHUbuVkAMNKsb

